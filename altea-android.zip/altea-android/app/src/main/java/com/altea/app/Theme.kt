package com.altea.app

import android.graphics.BitmapFactory
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File

data class Palette(
    val bg: Color,
    val card: Color,
    val text: Color,
    val sub: Color,
    val chip: Color,
    val accent: Color,
    val blue: Color,
    val danger: Color
)

val ACCENTS = listOf(
    Color(0xFFE53935),   // rojo
    Color(0xFF2F80ED),   // azul
    Color(0xFF8E5CF5),   // morado
    Color(0xFF1FBF9E),   // turquesa
    Color(0xFFFF8A3D),   // naranja
    Color(0xFFFF5CA8)    // rosa
)

fun defaultAccent(s: Settings): Int {
    if (!Health.isKid(s)) return 0
    return when (s.sex) {
        "f" -> 5
        "m" -> 1
        else -> 3
    }
}

fun makePalette(s: Settings): Palette {
    val idx = if (s.accent in ACCENTS.indices) s.accent else defaultAccent(s)
    val accent = ACCENTS[idx]
    return if (Health.isKid(s)) {
        Palette(
            bg = Color(0xFFFFF6E0), card = Color(0xFFFFFFFF), text = Color(0xFF26264F),
            sub = Color(0xFF6C6C99), chip = Color(0xFFFFE9B8), accent = accent,
            blue = Color(0xFF2F80ED), danger = Color(0xFFE53935)
        )
    } else {
        Palette(
            bg = Color(0xFF080B12), card = Color(0xFF131B2B), text = Color(0xFFEAF0FA),
            sub = Color(0xFF8FA3BF), chip = Color(0xFF223049), accent = accent,
            blue = Color(0xFF2F80ED), danger = Color(0xFFE53935)
        )
    }
}

val LocalPal = staticCompositionLocalOf { makePalette(Settings()) }
val LocalLang = staticCompositionLocalOf { "es" }
val LocalKid = staticCompositionLocalOf { false }

@Composable
fun t(key: String): String = Tr.get(key, LocalLang.current)

@Composable
fun tf(key: String, vararg args: Any?): String = Tr.fmt(key, LocalLang.current, *args)

@Composable
fun AlteaTheme(s: Settings, content: @Composable () -> Unit) {
    val kid = Health.isKid(s)
    val pal = makePalette(s)
    val scheme = if (kid) {
        lightColorScheme(
            primary = pal.accent, onPrimary = Color.White, background = pal.bg, onBackground = pal.text,
            surface = pal.card, onSurface = pal.text, surfaceVariant = pal.chip, onSurfaceVariant = pal.sub
        )
    } else {
        darkColorScheme(
            primary = pal.accent, onPrimary = Color.White, background = pal.bg, onBackground = pal.text,
            surface = pal.card, onSurface = pal.text, surfaceVariant = pal.chip, onSurfaceVariant = pal.sub
        )
    }
    CompositionLocalProvider(LocalPal provides pal, LocalLang provides s.lang, LocalKid provides kid) {
        MaterialTheme(colorScheme = scheme) {
            Surface(modifier = Modifier.fillMaxSize(), color = pal.bg, contentColor = pal.text) {
                Box(Modifier.fillMaxSize()) {
                    BackgroundLayer(s, kid)
                    content()
                }
            }
        }
    }
}

/** Decodifica una imagen reduciendola para no gastar memoria. */
fun loadBitmap(path: String, maxSide: Int): ImageBitmap? {
    if (path.isBlank()) return null
    return try {
        if (!File(path).exists()) return null
        val bounds = BitmapFactory.Options()
        bounds.inJustDecodeBounds = true
        BitmapFactory.decodeFile(path, bounds)
        var sample = 1
        while (bounds.outWidth / sample > maxSide || bounds.outHeight / sample > maxSide) sample *= 2
        val opts = BitmapFactory.Options()
        opts.inSampleSize = sample
        BitmapFactory.decodeFile(path, opts)?.asImageBitmap()
    } catch (e: Exception) {
        null
    }
}

@Composable
fun BackgroundLayer(s: Settings, kid: Boolean) {
    val pal = LocalPal.current
    val bg = remember(s.bgPath) { loadBitmap(s.bgPath, 1280) }
    if (bg != null) {
        Image(
            bitmap = bg, contentDescription = null, contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize(), alpha = 0.45f
        )
        Box(Modifier.fillMaxSize().background(pal.bg.copy(alpha = 0.45f)))
    }
    if (kid) {
        val list = when (s.sex) {
            "m" -> listOf("🚗", "🚕", "🚙", "🚓", "🚌", "🏎️")
            "f" -> listOf("🌸", "🌼", "🌺", "🌷", "🦋", "🌻")
            else -> listOf("⭐", "🎈", "🌈", "🦄", "🐥", "🎨")
        }
        FloatingDecor(list)
    }
}

/** Dibujos que flotan hacia arriba detras de la pantalla (modo infantil). */
@Composable
fun FloatingDecor(emojis: List<String>) {
    val inf = rememberInfiniteTransition(label = "float")
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val w: Dp = maxWidth
        val h: Dp = maxHeight
        for (i in 0 until 9) {
            val p by inf.animateFloat(
                initialValue = (i % 4) * 0.25f,
                targetValue = (i % 4) * 0.25f + 1f,
                animationSpec = infiniteRepeatable(tween(9000 + i * 1400, easing = LinearEasing), RepeatMode.Restart),
                label = "p$i"
            )
            val frac = p - Math.floor(p.toDouble()).toFloat()
            Text(
                text = emojis[i % emojis.size],
                fontSize = (24 + (i % 3) * 10).sp,
                modifier = Modifier
                    .offset(x = w * (0.03f + i * 0.105f), y = h * (1.05f - 1.15f * frac))
                    .padding(0.dp)
            )
        }
    }
}

@Composable
fun Panel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val pal = LocalPal.current
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = pal.card.copy(alpha = 0.94f))
    ) {
        Column(Modifier.padding(16.dp), content = content)
    }
}

/** Logo de la app (el del usuario si eligio uno) sobre una tarjeta blanca. */
@Composable
fun LogoBadge(path: String, size: Dp) {
    val custom = remember(path) { loadBitmap(path, 512) }
    Box(
        Modifier.size(size).clip(RoundedCornerShape(size / 4)).background(Color.White),
        contentAlignment = Alignment.Center
    ) {
        if (custom != null) {
            Image(bitmap = custom, contentDescription = "logo", modifier = Modifier.fillMaxSize().padding(size / 12), contentScale = ContentScale.Fit)
        } else {
            Image(painter = painterResource(R.drawable.logo), contentDescription = "ALTEA", modifier = Modifier.fillMaxSize().padding(size / 12), contentScale = ContentScale.Fit)
        }
    }
}

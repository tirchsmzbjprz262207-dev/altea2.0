package com.altea.app

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private const val ROUND = 10

/** Preguntas de verdadero/falso y opcion multiple, en rondas de 10 tomadas de un banco de 50. */
@Composable
fun QuizScreen() {
    val lang = LocalLang.current
    val pal = LocalPal.current
    val li = if (lang == "es") 0 else 1      // preguntas en espanol; el resto de idiomas las ve en ingles

    var order by remember { mutableStateOf(QUIZ.indices.shuffled()) }
    var pos by remember { mutableStateOf(0) }       // inicio de la ronda dentro de "order"
    var n by remember { mutableStateOf(0) }         // preguntas ya contestadas en la ronda
    var picked by remember { mutableStateOf(-1) }
    var score by remember { mutableStateOf(0) }

    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(t("quiz_title"), fontSize = 22.sp, fontWeight = FontWeight.Bold)

        if (n >= ROUND) {
            Panel {
                Text(t("quiz_done"), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text(tf("quiz_result", score, ROUND), fontSize = 18.sp)
                Spacer(Modifier.height(12.dp))
                Button(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        pos += ROUND
                        if (pos + ROUND > QUIZ.size) {
                            order = QUIZ.indices.shuffled()
                            pos = 0
                        }
                        n = 0
                        score = 0
                        picked = -1
                    }
                ) { Text(t("quiz_again")) }
            }
        } else {
            val item = QUIZ[order[pos + n]]
            val labels = if (item.isTf) listOf(t("quiz_true"), t("quiz_false")) else item.opts[li]
            Panel {
                Text(tf("quiz_q_of", n + 1, ROUND), color = pal.sub, fontSize = 13.sp)
                Spacer(Modifier.height(6.dp))
                Text(item.q[li], fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(12.dp))
                labels.forEachIndexed { i, label ->
                    val bg = when {
                        picked < 0 -> pal.chip
                        i == item.answer -> Color(0xFF2E9E5B)
                        i == picked -> pal.danger
                        else -> pal.chip
                    }
                    val fg = if (picked >= 0 && (i == item.answer || i == picked)) Color.White else pal.text
                    Button(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = bg, contentColor = fg),
                        onClick = {
                            if (picked < 0) {
                                picked = i
                                if (i == item.answer) score++
                            }
                        }
                    ) { Text(label) }
                }
                if (picked >= 0) {
                    Spacer(Modifier.height(10.dp))
                    Text(
                        if (picked == item.answer) t("quiz_right") else t("quiz_wrong"),
                        fontWeight = FontWeight.Bold,
                        color = if (picked == item.answer) Color(0xFF2E9E5B) else pal.danger
                    )
                    Text(item.exp[li])
                    Spacer(Modifier.height(10.dp))
                    Button(
                        modifier = Modifier.fillMaxWidth(),
                        onClick = { n++; picked = -1 }
                    ) { Text(t("quiz_next")) }
                }
            }
        }

        Text(t("quiz_note"), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

package com.altea.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Guarda ajustes, historial y lecturas en el almacenamiento privado de la app. */
class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("altea2", Context.MODE_PRIVATE)

    fun loadSettings(): Settings {
        val d = Settings()
        return Settings(
            onboarded = sp.getBoolean("onboarded", d.onboarded),
            lang = sp.getString("lang", d.lang) ?: d.lang,
            name = sp.getString("name", d.name) ?: d.name,
            age = sp.getInt("age", d.age),
            sex = sp.getString("sex", d.sex) ?: d.sex,
            weightKg = sp.getFloat("weightKg", d.weightKg.toFloat()).toDouble(),
            heightCm = sp.getInt("heightCm", d.heightCm),
            phone = sp.getString("phone", d.phone) ?: d.phone,
            contactName = sp.getString("contactName", d.contactName) ?: d.contactName,
            condHeart = sp.getBoolean("condHeart", d.condHeart),
            condHyper = sp.getBoolean("condHyper", d.condHyper),
            condDiabetes = sp.getBoolean("condDiabetes", d.condDiabetes),
            condAsthma = sp.getBoolean("condAsthma", d.condAsthma),
            condOther = sp.getString("condOther", d.condOther) ?: d.condOther,
            autoLimits = sp.getBoolean("autoLimits", d.autoLimits),
            hrMax = sp.getInt("hrMax", d.hrMax),
            hrMin = sp.getInt("hrMin", d.hrMin),
            jump = sp.getInt("jump", d.jump),
            fall = sp.getFloat("fall", d.fall.toFloat()).toDouble(),
            bandVibrate = sp.getBoolean("bandVibrate", d.bandVibrate),
            phoneAlert = sp.getBoolean("phoneAlert", d.phoneAlert),
            autoMsg = sp.getBoolean("autoMsg", d.autoMsg),
            msgDelaySec = sp.getInt("msgDelaySec", d.msgDelaySec),
            updateSec = sp.getInt("updateSec", d.updateSec),
            historyMin = sp.getInt("historyMin", d.historyMin),
            themeMode = sp.getString("themeMode", d.themeMode) ?: d.themeMode,
            accent = sp.getInt("accent", d.accent),
            showPulse = sp.getBoolean("showPulse", d.showPulse),
            showMove = sp.getBoolean("showMove", d.showMove),
            showTilt = sp.getBoolean("showTilt", d.showTilt),
            showMini = sp.getBoolean("showMini", d.showMini),
            bgPath = sp.getString("bgPath", d.bgPath) ?: d.bgPath,
            logoPath = sp.getString("logoPath", d.logoPath) ?: d.logoPath,
            kidDecor = sp.getString("kidDecor", d.kidDecor) ?: d.kidDecor,
            notes = sp.getString("notes", d.notes) ?: d.notes
        )
    }

    fun saveSettings(s: Settings) {
        sp.edit()
            .putBoolean("onboarded", s.onboarded)
            .putString("lang", s.lang)
            .putString("name", s.name)
            .putInt("age", s.age)
            .putString("sex", s.sex)
            .putFloat("weightKg", s.weightKg.toFloat())
            .putInt("heightCm", s.heightCm)
            .putString("phone", s.phone)
            .putString("contactName", s.contactName)
            .putBoolean("condHeart", s.condHeart)
            .putBoolean("condHyper", s.condHyper)
            .putBoolean("condDiabetes", s.condDiabetes)
            .putBoolean("condAsthma", s.condAsthma)
            .putString("condOther", s.condOther)
            .putBoolean("autoLimits", s.autoLimits)
            .putInt("hrMax", s.hrMax)
            .putInt("hrMin", s.hrMin)
            .putInt("jump", s.jump)
            .putFloat("fall", s.fall.toFloat())
            .putBoolean("bandVibrate", s.bandVibrate)
            .putBoolean("phoneAlert", s.phoneAlert)
            .putBoolean("autoMsg", s.autoMsg)
            .putInt("msgDelaySec", s.msgDelaySec)
            .putInt("updateSec", s.updateSec)
            .putInt("historyMin", s.historyMin)
            .putString("themeMode", s.themeMode)
            .putInt("accent", s.accent)
            .putBoolean("showPulse", s.showPulse)
            .putBoolean("showMove", s.showMove)
            .putBoolean("showTilt", s.showTilt)
            .putBoolean("showMini", s.showMini)
            .putString("bgPath", s.bgPath)
            .putString("logoPath", s.logoPath)
            .putString("kidDecor", s.kidDecor)
            .putString("notes", s.notes)
            .apply()
    }

    fun loadEvents(): List<EventRec> {
        return try {
            val a = JSONArray(sp.getString("events", "[]") ?: "[]")
            (0 until a.length()).map { i ->
                val j = a.getJSONObject(i)
                EventRec(
                    t = j.getLong("t"),
                    type = j.getString("type"),
                    detail = j.getString("detail"),
                    sev = j.optInt("sev", 0),
                    note = j.optString("note", ""),
                    hr = j.optInt("hr", 0),
                    mov = j.optDouble("mov", 0.0),
                    lat = if (j.has("lat")) j.getDouble("lat") else null,
                    lon = if (j.has("lon")) j.getDouble("lon") else null,
                    place = j.optString("place", "")
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveEvents(list: List<EventRec>) {
        val a = JSONArray()
        list.forEach { e ->
            val j = JSONObject()
                .put("t", e.t)
                .put("type", e.type)
                .put("detail", e.detail)
                .put("sev", e.sev)
                .put("note", e.note)
                .put("hr", e.hr)
                .put("mov", e.mov)
            if (e.lat != null) j.put("lat", e.lat)
            if (e.lon != null) j.put("lon", e.lon)
            j.put("place", e.place)
            a.put(j)
        }
        sp.edit().putString("events", a.toString()).apply()
    }

    fun loadSamples(): List<Sample> {
        return try {
            val a = JSONArray(sp.getString("samples", "[]") ?: "[]")
            (0 until a.length()).map { i ->
                val r = a.getJSONArray(i)
                Sample(r.getLong(0), r.getInt(1), r.getInt(2), r.getInt(3), r.getDouble(4))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveSamples(list: List<Sample>) {
        val a = JSONArray()
        list.forEach { s ->
            a.put(JSONArray().put(s.t).put(s.avg).put(s.min).put(s.max).put(s.mov))
        }
        sp.edit().putString("samples", a.toString()).apply()
    }
}

package com.altea.app

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.PowerManager
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private fun upd(f: (Settings) -> Settings) {
    Altea.updateSettings(f(Altea.settings.value))
}

@Composable
fun SettingsScreen(act: MainActivity, onClose: () -> Unit) {
    val s by Altea.settings.collectAsState()
    val pal = LocalPal.current
    val lim = Health.limits(s)
    val range = Health.normalRange(s.age)

    // campos de texto: se guardan con el boton "Guardar"
    var phone by remember { mutableStateOf(s.phone) }
    var contact by remember { mutableStateOf(s.contactName) }
    var name by remember { mutableStateOf(s.name) }
    var age by remember { mutableStateOf(if (s.age > 0) s.age.toString() else "") }
    var weight by remember { mutableStateOf(if (s.weightKg > 0) s.weightKg.toString() else "") }
    var height by remember { mutableStateOf(if (s.heightCm > 0) s.heightCm.toString() else "") }
    var other by remember { mutableStateOf(s.condOther) }
    var hrMax by remember { mutableStateOf(s.hrMax.toString()) }
    var hrMin by remember { mutableStateOf(s.hrMin.toString()) }
    var jump by remember { mutableStateOf(s.jump.toString()) }
    var fall by remember { mutableStateOf(s.fall.toString()) }
    var saved by remember { mutableStateOf(false) }

    Surface(Modifier.fillMaxSize(), color = pal.bg, contentColor = pal.text) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onClose) { Text("←", fontSize = 24.sp) }
                Text(t("set_title"), fontSize = 22.sp, fontWeight = FontWeight.Bold)
            }
            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Panel {
                    SectionTitle(t("sec_lang"))
                    Spacer(Modifier.height(8.dp))
                    ChoiceChips(Tr.langs, s.lang) { code -> upd { it.copy(lang = code) } }
                }

                Panel {
                    SectionTitle(t("sec_contact"))
                    Spacer(Modifier.height(8.dp))
                    Field(t("f_phone"), phone, KeyboardType.Phone, t("ph_hint")) { phone = it; saved = false }
                    Spacer(Modifier.height(8.dp))
                    Field(t("f_contact_name"), contact, KeyboardType.Text) { contact = it; saved = false }
                }

                Panel {
                    SectionTitle(t("sec_profile"))
                    Spacer(Modifier.height(8.dp))
                    Field(t("f_name"), name, KeyboardType.Text) { name = it; saved = false }
                    Spacer(Modifier.height(8.dp))
                    Field(t("f_age"), age, KeyboardType.Number) { age = it.filter { c -> c.isDigit() }.take(3); saved = false }
                    Spacer(Modifier.height(8.dp))
                    Text(t("f_sex"))
                    ChoiceChips(
                        listOf("m" to t("sex_m"), "f" to t("sex_f"), "o" to t("sex_o")), s.sex
                    ) { v -> upd { it.copy(sex = if (it.sex == v) "" else v) } }
                    Spacer(Modifier.height(8.dp))
                    Field(t("f_weight"), weight, KeyboardType.Decimal) { weight = it; saved = false }
                    Spacer(Modifier.height(8.dp))
                    Field(t("f_height"), height, KeyboardType.Number) { height = it.filter { c -> c.isDigit() }.take(3); saved = false }
                }

                Panel {
                    SectionTitle(t("sec_health"))
                    Spacer(Modifier.height(4.dp))
                    SwitchRow(t("c_heart"), s.condHeart) { v -> upd { it.copy(condHeart = v) } }
                    SwitchRow(t("c_hyper"), s.condHyper) { v -> upd { it.copy(condHyper = v) } }
                    SwitchRow(t("c_diab"), s.condDiabetes) { v -> upd { it.copy(condDiabetes = v) } }
                    SwitchRow(t("c_asthma"), s.condAsthma) { v -> upd { it.copy(condAsthma = v) } }
                    Spacer(Modifier.height(8.dp))
                    Field(t("c_other"), other, KeyboardType.Text) { other = it; saved = false }
                }

                Panel {
                    SectionTitle(t("sec_alerts"))
                    Spacer(Modifier.height(4.dp))
                    SwitchRow(t("auto_limits"), s.autoLimits) { v -> upd { it.copy(autoLimits = v) } }
                    Text(
                        tf("rec_range", range.first, range.second) + "  (" + lim.alertMin + " / " + lim.alertMax + ")",
                        fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (!s.autoLimits) {
                        Spacer(Modifier.height(8.dp))
                        Field(t("lim_hi"), hrMax, KeyboardType.Number) { hrMax = it.filter { c -> c.isDigit() }.take(3); saved = false }
                        Spacer(Modifier.height(8.dp))
                        Field(t("lim_lo"), hrMin, KeyboardType.Number) { hrMin = it.filter { c -> c.isDigit() }.take(3); saved = false }
                        Spacer(Modifier.height(8.dp))
                        Field(t("lim_jump"), jump, KeyboardType.Number) { jump = it.filter { c -> c.isDigit() }.take(3); saved = false }
                    }
                    Spacer(Modifier.height(8.dp))
                    Field(t("lim_fall"), fall, KeyboardType.Decimal) { fall = it; saved = false }
                    Spacer(Modifier.height(8.dp))
                    SwitchRow(t("vib_band"), s.bandVibrate) { v -> upd { it.copy(bandVibrate = v) } }
                    SwitchRow(t("vib_phone"), s.phoneAlert) { v -> upd { it.copy(phoneAlert = v) } }
                    SwitchRow(t("auto_msg"), s.autoMsg) { v -> upd { it.copy(autoMsg = v) } }
                    Spacer(Modifier.height(8.dp))
                    Text(t("msg_delay"))
                    NumberChips(listOf(10, 20, 30, 60), s.msgDelaySec, "s") { v -> upd { it.copy(msgDelaySec = v) } }
                }

                Panel {
                    SectionTitle(t("sec_data"))
                    Spacer(Modifier.height(8.dp))
                    Text(t("upd_int"))
                    NumberChips(listOf(1, 2, 3, 5, 10), s.updateSec, "s") { v -> upd { it.copy(updateSec = v) } }
                    Spacer(Modifier.height(12.dp))
                    Text(t("hist_int"))
                    NumberChips(listOf(5, 10, 15, 30, 45, 60), s.historyMin, "min") { v -> upd { it.copy(historyMin = v) } }
                }

                PermissionsPanel(act)

                Text(t("disclaimer"), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            Surface(color = pal.card, modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(onClick = {
                        upd {
                            it.copy(
                                phone = phone.trim(),
                                contactName = contact.trim(),
                                name = name.trim(),
                                age = (age.toIntOrNull() ?: it.age).coerceIn(0, 120),
                                weightKg = weight.replace(',', '.').toDoubleOrNull() ?: 0.0,
                                heightCm = height.toIntOrNull() ?: 0,
                                condOther = other.trim(),
                                hrMax = hrMax.toIntOrNull() ?: it.hrMax,
                                hrMin = hrMin.toIntOrNull() ?: it.hrMin,
                                jump = jump.toIntOrNull() ?: it.jump,
                                fall = fall.replace(',', '.').toDoubleOrNull() ?: it.fall
                            )
                        }
                        saved = true
                    }) { Text(t("btn_save")) }
                    if (saved) Text(t("saved"), color = pal.accent)
                }
            }
        }
    }
}

@Composable
fun PermissionsPanel(act: MainActivity) {
    val ctx = LocalContext.current
    val tick = act.permTick.value      // se vuelve a calcular al volver a la app
    val pm = ctx.getSystemService(PowerManager::class.java)
    val rows = listOf(
        Triple("p_bt", act.bleGranted(), 0),
        Triple("p_loc", act.has(Manifest.permission.ACCESS_FINE_LOCATION) || act.has(Manifest.permission.ACCESS_COARSE_LOCATION), 0),
        Triple("p_sms", act.has(Manifest.permission.SEND_SMS), 0),
        Triple("p_notif", Build.VERSION.SDK_INT < 33 || act.has(Manifest.permission.POST_NOTIFICATIONS), 0),
        Triple("p_batt", pm != null && pm.isIgnoringBatteryOptimizations(ctx.packageName), 1)
    )
    Panel {
        SectionTitle(t("sec_perm"))
        Spacer(Modifier.height(4.dp))
        rows.forEach { (key, ok, kind) ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text(t(key))
                    Text(
                        if (ok) "✔ " + t("granted") else "✖",
                        fontSize = 12.sp,
                        color = if (ok) LocalPal.current.accent else LocalPal.current.danger
                    )
                }
                if (!ok) {
                    OutlinedButton(onClick = {
                        if (kind == 1) {
                            try {
                                ctx.startActivity(Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                            } catch (e: Exception) {
                                Toast.makeText(ctx, "Settings > Apps > ALTEA > Battery", Toast.LENGTH_LONG).show()
                            }
                        } else {
                            act.askPermissions()
                        }
                    }) { Text(t("grant")) }
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(t("p_fall_note"), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (tick < 0) Text("")
    }
}

package com.altea.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings as SettingsIcon
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    /** Sube cada vez que cambian los permisos, para que la pantalla de ajustes se actualice. */
    val permTick = mutableStateOf(0)

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        permTick.value = permTick.value + 1
        if (bleGranted()) {
            startSvc()
        } else {
            Toast.makeText(this, Altea.tr("p_bt"), Toast.LENGTH_LONG).show()
        }
    }

    fun has(p: String): Boolean =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    fun bleGranted(): Boolean = if (Build.VERSION.SDK_INT >= 31) {
        has(Manifest.permission.BLUETOOTH_SCAN) && has(Manifest.permission.BLUETOOTH_CONNECT)
    } else {
        has(Manifest.permission.ACCESS_FINE_LOCATION)
    }

    private fun wanted(): List<String> {
        val l = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.SEND_SMS
        )
        if (Build.VERSION.SDK_INT >= 31) {
            l.add(Manifest.permission.BLUETOOTH_SCAN)
            l.add(Manifest.permission.BLUETOOTH_CONNECT)
        }
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
        return l
    }

    /** Pide los permisos que falten y, si el Bluetooth esta listo, arranca la conexion en segundo plano. */
    fun askPermissions() {
        val missing = wanted().filter { !has(it) }
        if (missing.isEmpty()) {
            permTick.value = permTick.value + 1
            if (bleGranted()) startSvc()
        } else {
            permLauncher.launch(missing.toTypedArray())
        }
    }

    fun conectar() {
        askPermissions()
    }

    fun desconectar() {
        stopService(Intent(this, AlteaService::class.java))
    }

    private fun startSvc() {
        ContextCompat.startForegroundService(this, Intent(this, AlteaService::class.java))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { Root(this) }
        if (Altea.settings.value.onboarded && bleGranted() && !Altea.serviceOn.value) startSvc()
    }

    override fun onResume() {
        super.onResume()
        Altea.foreground = true
        permTick.value = permTick.value + 1
    }

    override fun onPause() {
        Altea.foreground = false
        super.onPause()
    }
}

@Composable
fun Root(act: MainActivity) {
    val s by Altea.settings.collectAsState()
    AlteaTheme(s) {
        if (!s.onboarded) {
            Onboarding(onDone = { act.askPermissions() })
        } else {
            MainShell(act)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MainShell(act: MainActivity) {
    var showSettings by remember { mutableStateOf(false) }
    val pager = rememberPagerState(pageCount = { 6 })
    val scope = rememberCoroutineScope()
    val pal = LocalPal.current
    val keys = listOf("tab_home", "tab_graph", "tab_symptoms", "tab_history", "tab_quiz", "tab_custom")
    val barKeys = listOf("tab_home", "tab_graph", "tab_symptoms", "tab_history", "tab_quiz", "tab_custom_s")
    val icons = listOf("🏠", "📈", "🩺", "🕘", "🧠", "🎨")

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { showSettings = true }) {
                Icon(
                    imageVector = Icons.Filled.SettingsIcon,
                    contentDescription = t("set_title"),
                    tint = pal.text,
                    modifier = Modifier.size(28.dp)
                )
            }
            Spacer(Modifier.weight(1f))
            Text(t(keys[pager.currentPage]), fontWeight = FontWeight.SemiBold, color = pal.sub)
            Spacer(Modifier.width(12.dp))
        }

        HorizontalPager(state = pager, modifier = Modifier.weight(1f)) { page ->
            when (page) {
                0 -> HomeScreen(act)
                1 -> GraphScreen()
                2 -> SymptomsScreen()
                3 -> HistoryScreen()
                4 -> QuizScreen()
                else -> CustomizeScreen()
            }
        }

        Row(
            Modifier.fillMaxWidth().background(pal.card.copy(alpha = 0.95f)).navigationBarsPadding().padding(vertical = 6.dp)
        ) {
            keys.forEachIndexed { i, k ->
                val on = pager.currentPage == i
                Column(
                    Modifier.weight(1f).clickable { scope.launch { pager.animateScrollToPage(i) } }.padding(vertical = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(icons[i], fontSize = 20.sp)
                    Text(
                        t(barKeys[i]), fontSize = 10.sp, maxLines = 1,
                        color = if (on) pal.accent else pal.sub,
                        fontWeight = if (on) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }
    }

    if (showSettings) {
        BackHandler { showSettings = false }
        SettingsScreen(act) { showSettings = false }
    }
}

package com.altea.app

import android.app.Application

class AlteaApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Altea.init(this)
    }
}

package com.altea.app

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File

/** Copia la imagen elegida al almacenamiento privado de la app y devuelve su ruta. */
fun copyImage(ctx: Context, uri: Uri, prefix: String): String? {
    return try {
        val out = File(ctx.filesDir, prefix + "_" + System.currentTimeMillis() + ".img")
        val input = ctx.contentResolver.openInputStream(uri) ?: return null
        input.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
        out.absolutePath
    } catch (e: Exception) {
        null
    }
}

private fun upd(f: (Settings) -> Settings) {
    Altea.updateSettings(f(Altea.settings.value))
}

@Composable
fun CustomizeScreen() {
    val s by Altea.settings.collectAsState()
    val ctx = LocalContext.current
    val pal = LocalPal.current

    val bgPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val p = copyImage(ctx, uri, "bg")
            if (p != null) upd { it.copy(bgPath = p) }
        }
    }
    val logoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val p = copyImage(ctx, uri, "logo")
            if (p != null) upd { it.copy(logoPath = p) }
        }
    }
    val current = if (s.accent in ACCENTS.indices) s.accent else defaultAccent(s)

    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(t("tab_custom"), fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(t("cus_hint"), color = MaterialTheme.colorScheme.onSurfaceVariant)

        Panel {
            SectionTitle(t("cus_theme"))
            Spacer(Modifier.height(8.dp))
            ChoiceChips(
                listOf("auto" to t("th_auto"), "adult" to t("th_adult"), "kid" to t("th_kid")),
                s.themeMode
            ) { m -> upd { it.copy(themeMode = m, accent = -1) } }
        }

        Panel {
            SectionTitle(t("cus_accent"))
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ACCENTS.forEachIndexed { i, c ->
                    Box(
                        Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(c)
                            .border(if (current == i) 3.dp else 0.dp, pal.text, CircleShape)
                            .clickable { upd { it.copy(accent = i) } }
                    )
                }
            }
        }

        Panel {
            SectionTitle(t("cus_panels"))
            Spacer(Modifier.height(4.dp))
            SwitchRow(t("pulse"), s.showPulse) { v -> upd { it.copy(showPulse = v) } }
            SwitchRow(t("movement"), s.showMove) { v -> upd { it.copy(showMove = v) } }
            SwitchRow(t("tilt"), s.showTilt) { v -> upd { it.copy(showTilt = v) } }
            SwitchRow(t("pn_mini"), s.showMini) { v -> upd { it.copy(showMini = v) } }
        }

        Panel {
            SectionTitle(t("cus_bg"))
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { bgPicker.launch("image/*") }) { Text(t("btn_choose")) }
                if (s.bgPath.isNotBlank()) {
                    OutlinedButton(onClick = { upd { it.copy(bgPath = "") } }) { Text(t("btn_remove")) }
                }
            }
        }

        Panel {
            SectionTitle(t("cus_logo"))
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                LogoBadge(s.logoPath, 64.dp)
                Button(onClick = { logoPicker.launch("image/*") }) { Text(t("btn_choose")) }
                if (s.logoPath.isNotBlank()) {
                    OutlinedButton(onClick = { upd { it.copy(logoPath = "") } }) { Text(t("btn_remove")) }
                }
            }
        }
    }
}

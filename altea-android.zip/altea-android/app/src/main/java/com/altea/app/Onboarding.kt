package com.altea.app

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Pantalla de registro que se ve la primera vez: contacto de emergencia (obligatorio) y datos personales. */
@Composable
fun Onboarding(onDone: () -> Unit) {
    val s by Altea.settings.collectAsState()
    var phone by remember { mutableStateOf(s.phone) }
    var contact by remember { mutableStateOf(s.contactName) }
    var name by remember { mutableStateOf(s.name) }
    var age by remember { mutableStateOf(if (s.age > 0) s.age.toString() else "") }
    var sex by remember { mutableStateOf(s.sex) }
    var weight by remember { mutableStateOf(if (s.weightKg > 0) s.weightKg.toString() else "") }
    var height by remember { mutableStateOf(if (s.heightCm > 0) s.heightCm.toString() else "") }
    var notes by remember { mutableStateOf(s.notes) }
    var phoneErr by remember { mutableStateOf(false) }
    var ageErr by remember { mutableStateOf(false) }

    Column(
        Modifier.statusBarsPadding().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        LogoBadge(s.logoPath, 120.dp)
        Text(t("ob_welcome"), fontSize = 24.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Text(t("ob_sub"), textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)

        Panel {
            SectionTitle(t("sec_lang"))
            Spacer(Modifier.height(8.dp))
            ChoiceChips(Tr.langs, s.lang) { code -> Altea.updateSettings(s.copy(lang = code)) }
        }

        Panel {
            SectionTitle(t("sec_contact"))
            Spacer(Modifier.height(8.dp))
            Field(t("f_phone"), phone, KeyboardType.Phone, t("ph_hint")) { phone = it; phoneErr = false }
            if (phoneErr) Text(t("ob_phone_err"), color = LocalPal.current.danger, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            Field(t("f_contact_name"), contact, KeyboardType.Text) { contact = it }
        }

        Panel {
            SectionTitle(t("sec_profile"))
            Spacer(Modifier.height(8.dp))
            Field(t("f_name"), name, KeyboardType.Text) { name = it }
            Spacer(Modifier.height(8.dp))
            Field(t("f_age"), age, KeyboardType.Number) { age = it.filter { c -> c.isDigit() }.take(3); ageErr = false }
            if (ageErr) Text(t("ob_age_err"), color = LocalPal.current.danger, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            Text(t("f_sex"))
            ChoiceChips(
                listOf("m" to t("sex_m"), "f" to t("sex_f"), "o" to t("sex_o")), sex
            ) { sex = if (sex == it) "" else it }
            Spacer(Modifier.height(8.dp))
            Field(t("f_weight"), weight, KeyboardType.Decimal) { weight = it }
            Spacer(Modifier.height(8.dp))
            Field(t("f_height"), height, KeyboardType.Number) { height = it.filter { c -> c.isDigit() }.take(3) }
            Spacer(Modifier.height(8.dp))
            Field(t("f_notes"), notes, KeyboardType.Text) { notes = it }
        }

        Text(t("ob_perm_note"), fontSize = 13.sp, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(t("disclaimer"), fontSize = 12.sp, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)

        Button(
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                val digits = phone.count { it.isDigit() }
                val ageNum = age.toIntOrNull() ?: 0
                phoneErr = digits < 8
                ageErr = ageNum !in 1..120
                if (!phoneErr && !ageErr) {
                    Altea.updateSettings(
                        s.copy(
                            phone = phone.trim(),
                            contactName = contact.trim(),
                            name = name.trim(),
                            age = ageNum,
                            sex = sex,
                            weightKg = weight.replace(',', '.').toDoubleOrNull() ?: 0.0,
                            heightCm = height.toIntOrNull() ?: 0,
                            notes = notes.trim(),
                            onboarded = true
                        )
                    )
                    onDone()
                }
            }
        ) { Text(t("btn_continue")) }
        Spacer(Modifier.height(24.dp))
    }
}

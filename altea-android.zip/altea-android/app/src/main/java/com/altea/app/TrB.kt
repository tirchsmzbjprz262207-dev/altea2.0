package com.altea.app

// Orden: es, en, fr, it, ja, zh, ru
internal val STR_B: Map<String, List<String>> = mapOf(
    // ---- personalizar ----
    "cus_hint" to listOf(
        "Cambia el fondo, el logo, los paneles y los colores para que la app sea más tuya.",
        "Change the background, logo, panels and colors to make the app yours.",
        "Changez le fond, le logo, les panneaux et les couleurs pour personnaliser l'appli.",
        "Cambia sfondo, logo, pannelli e colori per rendere l'app più tua.",
        "背景、ロゴ、パネル、色を変えて、自分らしいアプリにしましょう。",
        "更改背景、徽标、面板和颜色，让应用更有个性。",
        "Измените фон, логотип, панели и цвета, чтобы приложение стало вашим."
    ),
    "cus_theme" to listOf("Tema", "Theme", "Thème", "Tema", "テーマ", "主题", "Тема"),
    "th_auto" to listOf("Automático (por edad)", "Automatic (by age)", "Automatique (selon l'âge)", "Automatico (in base all'età)", "自動（年齢別）", "自动（按年龄）", "Авто (по возрасту)"),
    "th_adult" to listOf("Adulto", "Adult", "Adulte", "Adulto", "大人", "成人", "Взрослый"),
    "th_kid" to listOf("Infantil", "Kids", "Enfant", "Bambini", "子ども", "儿童", "Детский"),
    "cus_panels" to listOf("Paneles en inicio", "Home panels", "Panneaux de l'accueil", "Pannelli nella home", "ホームのパネル", "首页面板", "Панели на главной"),
    "pn_mini" to listOf("Mini gráfica", "Mini graph", "Mini-graphique", "Mini grafico", "ミニグラフ", "迷你图表", "Мини-график"),
    "cus_bg" to listOf("Fondo de pantalla", "Background image", "Image de fond", "Immagine di sfondo", "背景画像", "背景图片", "Фоновое изображение"),
    "cus_logo" to listOf("Logo", "Logo", "Logo", "Logo", "ロゴ", "徽标", "Логотип"),
    "btn_choose" to listOf("Elegir imagen", "Choose image", "Choisir une image", "Scegli immagine", "画像を選択", "选择图片", "Выбрать изображение"),
    "btn_remove" to listOf("Quitar", "Remove", "Retirer", "Rimuovi", "削除", "移除", "Убрать"),
    "cus_accent" to listOf("Color", "Color", "Couleur", "Colore", "色", "颜色", "Цвет"),

    // ---- ajustes ----
    "set_title" to listOf("Ajustes", "Settings", "Paramètres", "Impostazioni", "設定", "设置", "Настройки"),
    "sec_lang" to listOf("Idioma", "Language", "Langue", "Lingua", "言語", "语言", "Язык"),
    "sec_contact" to listOf("Contacto de emergencia", "Emergency contact", "Contact d'urgence", "Contatto di emergenza", "緊急連絡先", "紧急联系人", "Экстренный контакт"),
    "f_phone" to listOf("Teléfono del contacto", "Contact phone", "Téléphone du contact", "Telefono del contatto", "連絡先の電話番号", "联系人电话", "Телефон контакта"),
    "ph_hint" to listOf(
        "10 dígitos, o con lada del país (ej. 5216141234567)", "10 digits, or with country code (e.g. 15551234567)",
        "10 chiffres, ou avec l'indicatif du pays", "10 cifre, o con prefisso internazionale",
        "10桁、または国番号付き", "10位数字，或带国家区号", "10 цифр или с кодом страны"
    ),
    "f_contact_name" to listOf("Nombre del contacto (opcional)", "Contact name (optional)", "Nom du contact (facultatif)", "Nome del contatto (facoltativo)", "連絡先の名前（任意）", "联系人姓名（可选）", "Имя контакта (необязательно)"),
    "sec_profile" to listOf("Datos personales", "Personal data", "Données personnelles", "Dati personali", "個人情報", "个人资料", "Личные данные"),
    "f_name" to listOf("Nombre", "Name", "Nom", "Nome", "名前", "姓名", "Имя"),
    "f_age" to listOf("Edad", "Age", "Âge", "Età", "年齢", "年龄", "Возраст"),
    "f_sex" to listOf("Sexo", "Sex", "Sexe", "Sesso", "性別", "性别", "Пол"),
    "sex_m" to listOf("Hombre", "Male", "Homme", "Maschio", "男性", "男", "Мужской"),
    "sex_f" to listOf("Mujer", "Female", "Femme", "Femmina", "女性", "女", "Женский"),
    "sex_o" to listOf("Otro", "Other", "Autre", "Altro", "その他", "其他", "Другое"),
    "f_weight" to listOf("Peso (kg)", "Weight (kg)", "Poids (kg)", "Peso (kg)", "体重 (kg)", "体重 (kg)", "Вес (кг)"),
    "f_height" to listOf("Estatura (cm)", "Height (cm)", "Taille (cm)", "Altezza (cm)", "身長 (cm)", "身高 (cm)", "Рост (см)"),
    "sec_health" to listOf("Antecedentes de salud", "Health background", "Antécédents médicaux", "Anamnesi", "既往歴", "健康背景", "Анамнез"),
    "c_heart" to listOf("Problemas cardiacos", "Heart problems", "Problèmes cardiaques", "Problemi cardiaci", "心臓の病気", "心脏问题", "Болезни сердца"),
    "c_hyper" to listOf("Hipertensión", "Hypertension", "Hypertension", "Ipertensione", "高血圧", "高血压", "Гипертония"),
    "c_diab" to listOf("Diabetes", "Diabetes", "Diabète", "Diabete", "糖尿病", "糖尿病", "Диабет"),
    "c_asthma" to listOf("Asma", "Asthma", "Asthme", "Asma", "喘息", "哮喘", "Астма"),
    "c_other" to listOf("Otra enfermedad (opcional)", "Other condition (optional)", "Autre maladie (facultatif)", "Altra condizione (facoltativo)", "その他の病気（任意）", "其他疾病（可选）", "Другое заболевание (необязательно)"),
    "sec_alerts" to listOf("Alertas", "Alerts", "Alertes", "Allarmi", "アラート", "警报", "Оповещения"),
    "auto_limits" to listOf(
        "Usar límites recomendados por edad", "Use age-based recommended limits", "Utiliser les limites recommandées selon l'âge",
        "Usa i limiti consigliati in base all'età", "年齢に応じた推奨基準を使う", "按年龄使用推荐阈值", "Использовать рекомендуемые пределы по возрасту"
    ),
    "rec_range" to listOf(
        "Rango normal en reposo para tu edad: {0} a {1} bpm", "Normal resting range for your age: {0} to {1} bpm",
        "Plage normale au repos pour votre âge : {0} à {1} bpm", "Intervallo normale a riposo per la tua età: {0}-{1} bpm",
        "あなたの年齢の安静時の正常範囲: {0}〜{1} bpm", "你的年龄静息正常范围：{0} 至 {1} bpm", "Нормальный пульс в покое для вашего возраста: {0}–{1} bpm"
    ),
    "lim_hi" to listOf("Pulso máximo (bpm)", "Maximum pulse (bpm)", "Pouls maximum (bpm)", "Polso massimo (bpm)", "脈拍の上限 (bpm)", "脉搏上限 (bpm)", "Максимальный пульс (bpm)"),
    "lim_lo" to listOf("Pulso mínimo (bpm)", "Minimum pulse (bpm)", "Pouls minimum (bpm)", "Polso minimo (bpm)", "脈拍の下限 (bpm)", "脉搏下限 (bpm)", "Минимальный пульс (bpm)"),
    "lim_jump" to listOf("Subida brusca de pulso (bpm)", "Sudden pulse rise (bpm)", "Hausse brutale du pouls (bpm)", "Aumento improvviso del polso (bpm)", "脈拍の急上昇 (bpm)", "脉搏骤升 (bpm)", "Резкий рост пульса (bpm)"),
    "lim_fall" to listOf(
        "Caída: golpe fuerte (g)", "Fall: strong impact (g)", "Chute : choc fort (g)", "Caduta: forte impatto (g)",
        "転倒: 強い衝撃 (g)", "跌倒：强烈冲击 (g)", "Падение: сильный удар (g)"
    ),
    "vib_band" to listOf("Vibrar la pulsera en una alerta", "Vibrate the band on an alert", "Faire vibrer le bracelet lors d'une alerte", "Fai vibrare il braccialetto in un allarme", "警告時にバンドを振動させる", "警报时手环震动", "Вибрация браслета при тревоге"),
    "vib_phone" to listOf("Vibrar el celular en una alerta", "Vibrate the phone on an alert", "Faire vibrer le téléphone lors d'une alerte", "Fai vibrare il telefono in un allarme", "警告時にスマホを振動させる", "警报时手机震动", "Вибрация телефона при тревоге"),
    "auto_msg" to listOf(
        "Enviar mensaje automático (SMS y WhatsApp) con mi ubicación", "Send automatic message (SMS and WhatsApp) with my location",
        "Envoyer un message automatique (SMS et WhatsApp) avec ma position", "Invia messaggio automatico (SMS e WhatsApp) con la mia posizione",
        "位置情報つきの自動メッセージ（SMSとWhatsApp）を送る", "自动发送带位置的消息（短信和 WhatsApp）", "Автоматически отправлять сообщение (SMS и WhatsApp) с моим местоположением"
    ),
    "msg_delay" to listOf(
        "Segundos para cancelar antes de enviar", "Seconds to cancel before sending", "Secondes pour annuler avant l'envoi",
        "Secondi per annullare prima dell'invio", "送信前にキャンセルできる秒数", "发送前可取消的秒数", "Секунд на отмену перед отправкой"
    ),
    "sec_data" to listOf("Lectura de datos", "Data reading", "Lecture des données", "Lettura dei dati", "データ取得", "数据读取", "Считывание данных"),
    "upd_int" to listOf("Intervalo de actualización (segundos)", "Update interval (seconds)", "Intervalle de mise à jour (secondes)", "Intervallo di aggiornamento (secondi)", "更新間隔（秒）", "更新间隔（秒）", "Интервал обновления (секунды)"),
    "hist_int" to listOf(
        "Guardar en el historial cada (minutos)", "Save to history every (minutes)", "Enregistrer dans l'historique toutes les (minutes)",
        "Salva nella cronologia ogni (minuti)", "履歴に保存する間隔（分）", "每隔多少分钟保存到历史记录", "Сохранять в историю каждые (минуты)"
    ),

    // ---- permisos ----
    "sec_perm" to listOf(
        "Permisos de salud y sensores", "Health and sensor permissions", "Autorisations santé et capteurs",
        "Permessi salute e sensori", "ヘルスとセンサーの権限", "健康与传感器权限", "Разрешения для здоровья и датчиков"
    ),
    "p_bt" to listOf("Bluetooth (pulsera)", "Bluetooth (band)", "Bluetooth (bracelet)", "Bluetooth (braccialetto)", "Bluetooth（バンド）", "蓝牙（手环）", "Bluetooth (браслет)"),
    "p_loc" to listOf("Ubicación", "Location", "Position", "Posizione", "位置情報", "位置信息", "Местоположение"),
    "p_sms" to listOf("Enviar SMS", "Send SMS", "Envoyer des SMS", "Inviare SMS", "SMS送信", "发送短信", "Отправка SMS"),
    "p_notif" to listOf("Notificaciones", "Notifications", "Notifications", "Notifiche", "通知", "通知", "Уведомления"),
    "p_batt" to listOf(
        "Segundo plano (sin límite de batería)", "Background (no battery limit)", "Arrière-plan (sans limite de batterie)",
        "Background (senza limite batteria)", "バックグラウンド（バッテリー制限なし）", "后台运行（无电池限制）", "Фоновая работа (без ограничения батареи)"
    ),
    "granted" to listOf("Concedido", "Granted", "Accordé", "Concesso", "許可済み", "已授权", "Разрешено"),
    "grant" to listOf("Conceder", "Grant", "Accorder", "Concedi", "許可する", "授权", "Разрешить"),
    "p_fall_note" to listOf(
        "Las caídas y el movimiento se detectan con el acelerómetro de la pulsera.",
        "Falls and movement are detected with the band's accelerometer.",
        "Les chutes et le mouvement sont détectés par l'accéléromètre du bracelet.",
        "Cadute e movimento sono rilevati dall'accelerometro del braccialetto.",
        "転倒や動きはバンドの加速度センサーで検出します。",
        "跌倒和活动通过手环的加速度计检测。",
        "Падения и движение определяются акселерометром браслета."
    ),

    // ---- avisos y registro inicial ----
    "disclaimer" to listOf(
        "ALTEA es un prototipo de apoyo para registrar síntomas. No es un dispositivo médico ni sustituye a un profesional de salud. En una emergencia llama a los servicios de emergencia.",
        "ALTEA is a support prototype for logging symptoms. It is not a medical device and does not replace a healthcare professional. In an emergency, call your local emergency number.",
        "ALTEA est un prototype d'aide au suivi des symptômes. Ce n'est pas un dispositif médical et il ne remplace pas un professionnel de santé. En cas d'urgence, appelez les secours.",
        "ALTEA è un prototipo di supporto per registrare i sintomi. Non è un dispositivo medico e non sostituisce un professionista sanitario. In caso di emergenza chiama i soccorsi.",
        "ALTEAは症状を記録するための試作品です。医療機器ではなく、医療専門家の代わりにもなりません。緊急時は救急に連絡してください。",
        "ALTEA 是用于记录症状的辅助原型，不是医疗器械，也不能代替医护人员。紧急情况下请拨打急救电话。",
        "ALTEA — вспомогательный прототип для записи симптомов. Это не медицинское устройство, оно не заменяет врача. В экстренной ситуации звоните в экстренные службы."
    ),
    "btn_save" to listOf("Guardar", "Save", "Enregistrer", "Salva", "保存", "保存", "Сохранить"),
    "btn_continue" to listOf("Continuar", "Continue", "Continuer", "Continua", "続ける", "继续", "Продолжить"),
    "ob_welcome" to listOf("Bienvenido a ALTEA", "Welcome to ALTEA", "Bienvenue sur ALTEA", "Benvenuto in ALTEA", "ALTEAへようこそ", "欢迎使用 ALTEA", "Добро пожаловать в ALTEA"),
    "ob_sub" to listOf(
        "Cuéntanos un poco de ti. El teléfono de contacto es obligatorio: ahí enviaremos los avisos.",
        "Tell us a little about you. The contact phone is required: alerts will be sent there.",
        "Parlez-nous un peu de vous. Le téléphone du contact est obligatoire : les alertes y seront envoyées.",
        "Raccontaci un po' di te. Il telefono del contatto è obbligatorio: lì invieremo gli avvisi.",
        "あなたについて少し教えてください。連絡先の電話番号は必須です。警告はそこへ送信されます。",
        "请简单介绍一下自己。联系人电话为必填项，警报将发送到该号码。",
        "Расскажите немного о себе. Телефон контакта обязателен: на него будут отправляться оповещения."
    ),
    "ob_phone_err" to listOf(
        "Escribe un teléfono válido (mínimo 8 dígitos)", "Enter a valid phone number (at least 8 digits)", "Saisissez un numéro valide (8 chiffres minimum)",
        "Inserisci un numero valido (almeno 8 cifre)", "有効な電話番号を入力してください（8桁以上）", "请输入有效电话号码（至少8位）", "Введите корректный номер (не менее 8 цифр)"
    ),
    "ob_age_err" to listOf(
        "Escribe una edad válida (1 a 120)", "Enter a valid age (1 to 120)", "Saisissez un âge valide (1 à 120)",
        "Inserisci un'età valida (da 1 a 120)", "有効な年齢を入力してください（1〜120）", "请输入有效年龄（1 至 120）", "Введите корректный возраст (от 1 до 120)"
    ),
    "ob_optional" to listOf("Opcional", "Optional", "Facultatif", "Facoltativo", "任意", "可选", "Необязательно"),
    "ob_perm_note" to listOf(
        "Al continuar te pediremos permisos: Bluetooth, ubicación, SMS y notificaciones.",
        "When you continue we will ask for permissions: Bluetooth, location, SMS and notifications.",
        "En continuant, nous demanderons des autorisations : Bluetooth, position, SMS et notifications.",
        "Continuando ti chiederemo i permessi: Bluetooth, posizione, SMS e notifiche.",
        "続行すると、Bluetooth、位置情報、SMS、通知の権限を求めます。",
        "继续后将请求权限：蓝牙、位置、短信和通知。",
        "При продолжении мы запросим разрешения: Bluetooth, местоположение, SMS и уведомления."
    )
)

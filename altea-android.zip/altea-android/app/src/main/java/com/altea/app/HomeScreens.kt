package com.altea.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ---------------- INICIO ----------------

@Composable
fun HomeScreen(act: MainActivity) {
    val r by Altea.reading.collectAsState()
    val s by Altea.settings.collectAsState()
    val conn by Altea.connection.collectAsState()
    val on by Altea.serviceOn.collectAsState()
    val alert by Altea.alertCode.collectAsState()
    val msg by Altea.msgStatus.collectAsState()
    val live by Altea.hrLive.collectAsState()
    val pal = LocalPal.current
    val lim = Health.limits(s)

    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            LogoBadge(s.logoPath, 56.dp)
            Column(Modifier.weight(1f)) {
                Text("ALTEA", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text(t(conn), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Button(onClick = { if (on) act.desconectar() else act.conectar() }) {
                Text(if (on) t("btn_disconnect") else t("btn_connect"))
            }
        }

        alert?.let { AlertCard(it, msg) }

        if (s.showPulse) {
            val out = r.hr > 0 && (r.hr > lim.normalMax || r.hr < lim.normalMin)
            Panel {
                Text(t("pulse"), fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                    if (r.hr > 0) r.hr.toString() else "--",
                    fontSize = 64.sp, fontWeight = FontWeight.Bold,
                    color = if (out) pal.danger else pal.text
                )
                Text(t("bpm_unit"), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (r.hr <= 0) Text(t("no_data"), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        if (s.showMove || s.showTilt) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                if (s.showMove) {
                    val label = when {
                        r.mov < 0.08 -> t("rest")
                        r.mov < 0.4 -> t("light")
                        else -> t("intense")
                    }
                    Panel(Modifier.weight(1f)) {
                        Text(t("movement"), fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(label, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                        Text("%.2f g".format(r.mov), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                if (s.showTilt) {
                    Panel(Modifier.weight(1f)) {
                        Text(t("tilt"), fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("${r.tilt}°", fontSize = 26.sp, fontWeight = FontWeight.Bold)
                        Text("0° – 180°", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        if (s.showMini) {
            Panel {
                HrChart(live.takeLast(40), lim, 90.dp)
            }
        }

        if (alert == null) msg?.let { Text(it, fontSize = 13.sp) }
        Text(
            t("disclaimer"), fontSize = 11.sp, textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
        )
    }
}

@Composable
fun AlertCard(code: String, msg: String?) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val lang = LocalLang.current
    val pal = LocalPal.current
    val white = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF7A1220))
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = pal.danger)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                "⚠ " + t("alert_title") + ": " + Altea.describe(code, lang),
                color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp
            )
            if (msg != null) Text(msg, color = Color.White, fontSize = 14.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { Altea.dismissAlert() }, colors = white) { Text(t("btn_ok")) }
                Button(onClick = { Messenger.sendNow() }, colors = white) { Text(t("btn_send_now")) }
            }
            Button(onClick = { Messenger.shareWhatsApp(ctx) }, colors = white) { Text(t("btn_whatsapp")) }
        }
    }
}

// ---------------- GRAFICA EN TIEMPO REAL ----------------

@Composable
fun GraphScreen() {
    val live by Altea.hrLive.collectAsState()
    val r by Altea.reading.collectAsState()
    val s by Altea.settings.collectAsState()
    val lim = Health.limits(s)
    val pal = LocalPal.current

    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(t("graph_title"), fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Panel {
            Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(if (r.hr > 0) r.hr.toString() else "--", fontSize = 48.sp, fontWeight = FontWeight.Bold)
                Text("bpm", fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(bottom = 8.dp))
            }
            if (live.size < 2) {
                Text(t("graph_wait"), color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(180.dp))
            } else {
                HrChart(live, lim, 220.dp)
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("▇ " + t("normal_range") + ": " + lim.normalMin + "–" + lim.normalMax, fontSize = 12.sp, color = pal.accent)
            }
            if (live.isNotEmpty()) {
                Text(
                    t("hr_min") + " " + live.min() + "  ·  " + t("hr_avg") + " " + live.average().toInt() + "  ·  " + t("hr_max") + " " + live.max(),
                    fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

/** Grafica de pulso con la banda del rango normal y las lineas de alerta. */
@Composable
fun HrChart(data: List<Int>, lim: Limits, height: Dp) {
    val pal = LocalPal.current
    Canvas(Modifier.fillMaxWidth().height(height)) {
        val w = size.width
        val h = size.height
        val lo = (minOf(data.minOrNull() ?: lim.alertMin, lim.alertMin) - 5).toFloat()
        val hi = (maxOf(data.maxOrNull() ?: lim.alertMax, lim.alertMax) + 5).toFloat()
        fun y(v: Int): Float = h - (v - lo) / (hi - lo) * h

        // banda del rango normal
        val top = y(lim.normalMax)
        val bottom = y(lim.normalMin)
        drawRect(pal.accent.copy(alpha = 0.12f), Offset(0f, top), Size(w, bottom - top))
        // lineas de alerta
        val dash = PathEffect.dashPathEffect(floatArrayOf(14f, 10f))
        drawLine(pal.danger.copy(alpha = 0.6f), Offset(0f, y(lim.alertMax)), Offset(w, y(lim.alertMax)), 3f, pathEffect = dash)
        drawLine(pal.danger.copy(alpha = 0.6f), Offset(0f, y(lim.alertMin)), Offset(w, y(lim.alertMin)), 3f, pathEffect = dash)

        if (data.size >= 2) {
            val path = Path()
            data.forEachIndexed { i, v ->
                val x = i / (data.size - 1f) * w
                if (i == 0) path.moveTo(x, y(v)) else path.lineTo(x, y(v))
            }
            drawPath(path, pal.accent, style = Stroke(width = 6f, cap = StrokeCap.Round))
        }
    }
}

package com.altea.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Avisos por Telegram con un bot propio de ALTEA: el mensaje llega desde el bot (no desde tu numero),
 * puede ir a muchas personas o a un grupo, y se manda solo, sin tocar nada.
 */
object Telegram {
    private fun call(token: String, method: String, params: Map<String, String>): JSONObject? {
        return try {
            val body = params.entries.joinToString("&") {
                URLEncoder.encode(it.key, "UTF-8") + "=" + URLEncoder.encode(it.value, "UTF-8")
            }
            val c = URL("https://api.telegram.org/bot" + token.trim() + "/" + method).openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 10000
            c.readTimeout = 15000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
            c.outputStream.use { it.write(body.toByteArray()) }
            val stream = if (c.responseCode in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() }
            c.disconnect()
            if (text == null) null else JSONObject(text)
        } catch (e: Exception) {
            null
        }
    }

    /** Manda el texto (y la ubicacion como mapa) a todos los chats guardados. Devuelve a cuantos llego. */
    suspend fun send(text: String, lat: Double?, lon: Double?): Int = withContext(Dispatchers.IO) {
        val s = Altea.settings.value
        if (s.tgToken.isBlank()) return@withContext 0
        var ok = 0
        for (p in Contacts.parse(s.tgChats)) {
            val r = call(s.tgToken, "sendMessage", mapOf("chat_id" to p.value, "text" to text))
            if (r != null && r.optBoolean("ok")) {
                ok++
                if (lat != null && lon != null) {
                    call(
                        s.tgToken, "sendLocation",
                        mapOf("chat_id" to p.value, "latitude" to lat.toString(), "longitude" to lon.toString())
                    )
                }
            }
        }
        ok
    }

    /** Busca quien le escribio al bot (o lo agrego a un grupo) en las ultimas 24 horas. null = error. */
    suspend fun discover(token: String): List<Person>? = withContext(Dispatchers.IO) {
        val r = call(token, "getUpdates", mapOf("limit" to "100"))
        if (r == null || !r.optBoolean("ok")) return@withContext null
        val arr = r.optJSONArray("result") ?: return@withContext emptyList<Person>()
        val found = LinkedHashMap<String, String>()
        for (i in 0 until arr.length()) {
            val u = arr.optJSONObject(i) ?: continue
            val m = u.optJSONObject("message") ?: u.optJSONObject("my_chat_member") ?: continue
            val chat = m.optJSONObject("chat") ?: continue
            val id = chat.optLong("id").toString()
            var name = chat.optString("title")
            if (name.isBlank()) name = (chat.optString("first_name") + " " + chat.optString("last_name")).trim()
            if (name.isBlank()) name = chat.optString("username")
            found[id] = name
        }
        found.map { Person(it.value, it.key) }
    }
}

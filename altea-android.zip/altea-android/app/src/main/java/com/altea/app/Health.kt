package com.altea.app

data class Limits(
    val normalMin: Int,
    val normalMax: Int,
    val alertMin: Int,
    val alertMax: Int,
    val jump: Int
)

/**
 * Limites de pulso. Rangos normales en reposo (personas despiertas), segun Cleveland Clinic:
 * bebes 100-180, 1-3 anios 98-140, 3-5 anios 80-120, 5-12 anios 75-118, adolescentes y adultos 60-100.
 * Subida brusca: criterio de POTS, +30 lpm en adultos y +40 lpm en adolescentes (en los primeros 10 min de pararse).
 * Son valores de apoyo, no un diagnostico.
 */
object Health {
    fun normalRange(age: Int): Pair<Int, Int> = when {
        age <= 0 -> 60 to 100
        age < 1 -> 100 to 180
        age < 3 -> 98 to 140
        age < 5 -> 80 to 120
        age < 13 -> 75 to 118
        else -> 60 to 100
    }

    fun isKid(s: Settings): Boolean = when (s.themeMode) {
        "kid" -> true
        "adult" -> false
        else -> s.age in 1..12
    }

    fun limits(s: Settings): Limits {
        val (nMin, nMax) = normalRange(s.age)
        if (!s.autoLimits) {
            return Limits(nMin, nMax, s.hrMin, s.hrMax, s.jump)
        }
        var aMax = nMax + 20
        if (s.condHeart) aMax = nMax + 10       // con antecedentes cardiacos avisa antes
        // adultos y adolescentes: alerta con menos de 60 (la pulsera marca peligro igual); ninos: un poco por debajo de su rango
        val aMin = if (s.age <= 0 || s.age >= 13) nMin else nMin - 10
        val jump = if (s.age >= 20 || s.age <= 0) 30 else 40
        return Limits(nMin, nMax, aMin, aMax, jump)
    }

    /** Pulso maximo teorico aproximado (220 - edad). */
    fun maxHr(age: Int): Int = if (age in 1..120) 220 - age else 190

    fun conditionsText(s: Settings, name: (String) -> String): String {
        val l = mutableListOf<String>()
        if (s.condHeart) l.add(name("c_heart"))
        if (s.condHyper) l.add(name("c_hyper"))
        if (s.condDiabetes) l.add(name("c_diab"))
        if (s.condAsthma) l.add(name("c_asthma"))
        if (s.condOther.isNotBlank()) l.add(s.condOther.trim())
        if (s.notes.isNotBlank()) l.add(s.notes.trim())
        return l.joinToString(", ")
    }
}

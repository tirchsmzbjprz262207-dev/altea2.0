package com.altea.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import androidx.core.content.ContextCompat
import androidx.core.location.LocationManagerCompat
import androidx.core.os.CancellationSignal
import androidx.core.util.Consumer
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

/** Obtiene la ubicacion actual (o la ultima conocida). */
object Loc {
    @SuppressLint("MissingPermission")
    suspend fun get(ctx: Context): Location? {
        val fine = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fine && !coarse) return null
        val lm = ctx.getSystemService(LocationManager::class.java) ?: return null
        val candidates = if (fine) {
            listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
        } else {
            listOf(LocationManager.NETWORK_PROVIDER)
        }
        val provider = candidates.firstOrNull { lm.isProviderEnabled(it) }
        var loc: Location? = null
        if (provider != null) {
            loc = try {
                withTimeoutOrNull(8000) {
                    suspendCancellableCoroutine<Location?> { cont ->
                        val cs = CancellationSignal()
                        cont.invokeOnCancellation { cs.cancel() }
                        LocationManagerCompat.getCurrentLocation(
                            lm, provider, cs, ContextCompat.getMainExecutor(ctx),
                            Consumer<Location> { l -> if (cont.isActive) cont.resume(l) }
                        )
                    }
                }
            } catch (e: SecurityException) {
                null
            }
        }
        if (loc == null) {
            loc = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
                .mapNotNull { p -> try { lm.getLastKnownLocation(p) } catch (e: Exception) { null } }
                .maxByOrNull { it.time }
        }
        return loc
    }
}

package com.altea.app

import android.Manifest
import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch

/** Mantiene la conexion con la pulsera aunque la app este cerrada o la pantalla apagada. */
class AlteaService : Service() {
    private var ble: BleClient? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            Altea.ACTION_OK -> {
                Altea.dismissAlert()
                if (ble == null) {
                    stopSelf()
                    return START_NOT_STICKY
                }
                return START_STICKY
            }
        }

        if (!startFg()) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (ble == null) {
            val cliente = BleClient(
                this,
                onLine = { linea -> Altea.scope.launch { Altea.onLine(linea) } },
                onState = { texto, ok ->
                    Altea.scope.launch {
                        Altea.connection.value = texto
                        Altea.connected.value = ok
                        actualizarNotif(Altea.tr(texto))
                        if (ok) Altea.ble?.setInterval(Altea.settings.value.updateSec * 1000)
                    }
                }
            )
            ble = cliente
            Altea.ble = cliente
            Altea.serviceOn.value = true
            try {
                cliente.start()
            } catch (e: SecurityException) {
                stopSelf()
                return START_NOT_STICKY
            }
        }
        return START_STICKY
    }

    private fun startFg(): Boolean {
        var tipo = ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
        val coarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (fine == PackageManager.PERMISSION_GRANTED || coarse == PackageManager.PERMISSION_GRANTED) {
            tipo = tipo or ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
        }
        try {
            ServiceCompat.startForeground(this, 1, crearNotif(Altea.tr("st_scan")), tipo)
            return true
        } catch (e: Exception) {
            // si el sistema no deja usar el tipo "ubicacion", se intenta solo con dispositivo conectado
        }
        return try {
            ServiceCompat.startForeground(
                this, 1, crearNotif(Altea.tr("st_scan")),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
            )
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun crearNotif(texto: String): Notification {
        val abrir = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, Altea.CH_SERVICE)
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentTitle("ALTEA")
            .setContentText(texto)
            .setContentIntent(abrir)
            .setOngoing(true)
            .build()
    }

    private fun actualizarNotif(texto: String) {
        getSystemService(NotificationManager::class.java).notify(1, crearNotif(texto))
    }

    override fun onDestroy() {
        ble?.stop()
        ble = null
        Altea.ble = null
        Altea.serviceOn.value = false
        Altea.connected.value = false
        Altea.connection.value = "st_off"
        super.onDestroy()
    }
}

package com.altea.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import android.location.Geocoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** Centro de la app: guarda el estado que ve la pantalla y decide cuando hay una alerta. */
object Altea {
    const val CH_SERVICE = "altea_service"
    const val CH_ALERT = "altea_alert"
    const val ACTION_OK = "com.altea.app.OK"

    lateinit var app: Application
    private lateinit var store: Store
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    // Estado que observa la pantalla
    val settings = MutableStateFlow(Settings())
    val reading = MutableStateFlow(Reading())
    val hrLive = MutableStateFlow<List<Int>>(emptyList())
    val events = MutableStateFlow<List<EventRec>>(emptyList())
    val samples = MutableStateFlow<List<Sample>>(emptyList())
    val connection = MutableStateFlow("st_off")
    val connected = MutableStateFlow(false)
    val serviceOn = MutableStateFlow(false)
    val alertCode = MutableStateFlow<String?>(null)
    val msgStatus = MutableStateFlow<String?>(null)

    var ble: BleClient? = null
    var foreground = false
    var lastLat: Double? = null
    var lastLon: Double? = null

    private val recent = mutableListOf<Pair<Long, Int>>()
    private var lastAlert = 0L
    private var highSince = 0L
    private var lowSince = 0L
    private var jumpSince = 0L
    private var fallAt = 0L
    private var fallMovMax = 0.0

    // ventana del historial
    private var winStart = 0L
    private var winSum = 0L
    private var winCount = 0
    private var winMin = Int.MAX_VALUE
    private var winMax = 0
    private var winMov = 0.0
    private var winMovN = 0

    fun init(a: Application) {
        app = a
        store = Store(a)
        settings.value = store.loadSettings()
        events.value = store.loadEvents()
        samples.value = store.loadSamples()
        val nm = a.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_SERVICE, "ALTEA", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_ALERT, "ALTEA alerts", NotificationManager.IMPORTANCE_HIGH))
    }

    fun tr(key: String): String = Tr.get(key, settings.value.lang)

    fun updateSettings(s: Settings) {
        val old = settings.value
        settings.value = s
        store.saveSettings(s)
        if (old.updateSec != s.updateSec) ble?.setInterval(s.updateSec * 1000)
    }

    /** Texto de un evento en el idioma elegido. code: "hi:112", "lo:41", "jump:35", "fall" o clave de sintoma. */
    fun describe(code: String, lang: String): String {
        val p = code.split(":")
        val arg = p.getOrElse(1) { "" }
        return when (p[0]) {
            "hi" -> Tr.fmt("al_hi", lang, arg)
            "lo" -> Tr.fmt("al_lo", lang, arg)
            "jump" -> Tr.fmt("al_jump", lang, arg)
            "fall" -> Tr.get("al_fall", lang)
            "" -> ""
            else -> Tr.get(code, lang)
        }
    }

    // ---------- datos que llegan de la pulsera ----------

    fun onLine(line: String) {
        val p = line.trim().split(",")
        if (p.size == 5 && p[0] == "A") {
            val hr = p[1].toIntOrNull() ?: return
            val mov = p[2].toIntOrNull() ?: return
            val tilt = p[3].toIntOrNull() ?: return
            val peak = p[4].toIntOrNull() ?: return
            ingest(hr, mov / 100.0, tilt, peak / 100.0)
        } else if (p.size == 4) {
            // formato del firmware anterior: pulso,ax,ay,az (centesimas de g)
            val hr = p[0].toIntOrNull() ?: return
            val ax = (p[1].toIntOrNull() ?: return) / 100.0
            val ay = (p[2].toIntOrNull() ?: return) / 100.0
            val az = (p[3].toIntOrNull() ?: return) / 100.0
            val mag = sqrt(ax * ax + ay * ay + az * az)
            val tilt = if (mag > 0.1) Math.toDegrees(Math.acos((az / mag).coerceIn(-1.0, 1.0))).roundToInt() else 0
            ingest(hr, Math.abs(mag - 1.0), tilt, mag)
        }
    }

    fun ingest(hr: Int, mov: Double, tilt: Int, peak: Double) {
        val now = System.currentTimeMillis()
        reading.value = Reading(hr, mov, tilt, peak)
        if (hr > 0) {
            hrLive.value = (hrLive.value + hr).takeLast(150)
            recent.add(now to hr)
        }
        while (recent.isNotEmpty() && now - recent[0].first > 600_000L) recent.removeAt(0)
        accumulate(hr, mov, now)
        checkAlerts(hr, mov, peak, now)
    }

    private fun accumulate(hr: Int, mov: Double, now: Long) {
        if (winStart == 0L) winStart = now
        if (hr > 0) {
            winSum += hr
            winCount++
            if (hr < winMin) winMin = hr
            if (hr > winMax) winMax = hr
        }
        winMov += mov
        winMovN++
        val periodMs = settings.value.historyMin.coerceIn(5, 60) * 60_000L
        if (now - winStart >= periodMs) {
            val avg = if (winCount > 0) (winSum / winCount).toInt() else 0
            val mn = if (winCount > 0) winMin else 0
            val sample = Sample(now, avg, mn, winMax, (winMov / winMovN * 100).roundToInt() / 100.0)
            samples.value = (listOf(sample) + samples.value).take(2000)
            store.saveSamples(samples.value)
            winStart = now
            winSum = 0L
            winCount = 0
            winMin = Int.MAX_VALUE
            winMax = 0
            winMov = 0.0
            winMovN = 0
        }
    }

    // ---------- reglas de alerta ----------

    private fun checkAlerts(hr: Int, mov: Double, peak: Double, now: Long) {
        val s = settings.value
        val lim = Health.limits(s)
        val resting = mov < 0.4

        // caida: golpe fuerte y despues quietud
        if (peak >= s.fall && fallAt == 0L) {
            fallAt = now
            fallMovMax = 0.0
        } else if (fallAt != 0L) {
            if (mov > fallMovMax) fallMovMax = mov
            val wait = maxOf(8000L, s.updateSec * 2000L)
            if (now - fallAt >= wait) {
                if (fallMovMax < 0.25) alert("fall")
                fallAt = 0L
            }
        }

        // pulso alto (con movimiento fuerte se permite mas, por el ejercicio)
        val highLimit = if (resting) lim.alertMax else maxOf(lim.alertMax, (Health.maxHr(s.age) * 0.9).toInt())
        if (hr > 0 && hr > highLimit) {
            if (highSince == 0L) highSince = now
            if (now - highSince >= 10_000L) alert("hi:$hr")
        } else {
            highSince = 0L
        }

        // pulso bajo
        if (hr > 0 && hr < lim.alertMin) {
            if (lowSince == 0L) lowSince = now
            if (now - lowSince >= 10_000L) alert("lo:$hr")
        } else {
            lowSince = 0L
        }

        // subida brusca en reposo (respecto al minimo de los ultimos 10 minutos)
        if (hr > 0 && resting && recent.isNotEmpty()) {
            val base = recent.minOf { it.second }
            if (hr - base >= lim.jump) {
                if (jumpSince == 0L) jumpSince = now
                if (now - jumpSince >= 20_000L) alert("jump:${hr - base}")
            } else {
                jumpSince = 0L
            }
        } else {
            jumpSince = 0L
        }
    }

    private fun alert(code: String) {
        val now = System.currentTimeMillis()
        if (now - lastAlert < 60_000L) return      // una alerta por minuto como maximo
        lastAlert = now
        val s = settings.value
        addEvent("alert", code, 0, "")
        if (s.bandVibrate) ble?.vibrate(800)
        if (s.phoneAlert) vibratePhone()
        alertCode.value = code
        notifyAlert(code)
        if (s.autoMsg && s.phone.isNotBlank()) Messenger.startCountdown(code)
    }

    fun dismissAlert() {
        Messenger.cancel()
        alertCode.value = null
        ble?.vibrate(0)
        val nm = app.getSystemService(NotificationManager::class.java)
        nm.cancel(2)
        nm.cancel(3)
    }

    // ---------- eventos e historial ----------

    fun addEvent(type: String, detail: String, sev: Int, note: String) {
        val r = reading.value
        val ev = EventRec(
            System.currentTimeMillis(), type, detail, sev, note,
            r.hr, (r.mov * 100).roundToInt() / 100.0, lastLat, lastLon
        )
        events.value = (listOf(ev) + events.value).take(500)
        store.saveEvents(events.value)
        scope.launch {
            val loc = Loc.get(app) ?: return@launch
            lastLat = loc.latitude
            lastLon = loc.longitude
            events.value = events.value.map {
                if (it.t == ev.t) it.copy(lat = loc.latitude, lon = loc.longitude) else it
            }
            store.saveEvents(events.value)
            // direccion aproximada (solo si hay internet; si falla se queda con las coordenadas)
            val place = withContext(Dispatchers.IO) { addressOf(loc.latitude, loc.longitude) }
            if (place.isNotBlank()) {
                events.value = events.value.map { if (it.t == ev.t) it.copy(place = place) else it }
                store.saveEvents(events.value)
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun addressOf(lat: Double, lon: Double): String {
        return try {
            if (!Geocoder.isPresent()) return ""
            val l = Geocoder(app, Locale.getDefault()).getFromLocation(lat, lon, 1)
            l?.firstOrNull()?.getAddressLine(0) ?: ""
        } catch (e: Exception) {
            ""
        }
    }

    fun clearHistory() {
        events.value = emptyList()
        samples.value = emptyList()
        store.saveEvents(events.value)
        store.saveSamples(samples.value)
    }

    fun csv(): String {
        val lang = settings.value.lang
        val f = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        fun q(v: Any?) = "\"" + (v?.toString() ?: "").replace("\"", "\"\"") + "\""
        val sb = StringBuilder("date,type,detail,intensity,bpm,movement_g,lat,lon,place,note\n")
        events.value.reversed().forEach { e ->
            val row = listOf(f.format(Date(e.t)), e.type, describe(e.detail, lang), e.sev, e.hr, e.mov, e.lat, e.lon, e.place, e.note)
            sb.append(row.joinToString(",") { q(it) }).append('\n')
        }
        sb.append("\ndate,bpm_avg,bpm_min,bpm_max,movement_g\n")
        samples.value.reversed().forEach { s ->
            val row = listOf(f.format(Date(s.t)), s.avg, s.min, s.max, s.mov)
            sb.append(row.joinToString(",") { q(it) }).append('\n')
        }
        return sb.toString()
    }

    // ---------- avisos en el celular ----------

    private fun vibratePhone() {
        val v = app.getSystemService(Vibrator::class.java) ?: return
        v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 400, 150, 400, 150, 400), -1))
    }

    private fun notifyAlert(code: String) {
        val lang = settings.value.lang
        val ok = PendingIntent.getService(
            app, 1, Intent(app, AlteaService::class.java).setAction(ACTION_OK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val abrir = PendingIntent.getActivity(
            app, 2, Intent(app, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(app, CH_ALERT)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("ALTEA: " + Tr.get("alert_title", lang))
            .setContentText(describe(code, lang))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setContentIntent(abrir)
            .addAction(0, Tr.get("btn_ok", lang), ok)
            .setAutoCancel(true)
            .build()
        try {
            app.getSystemService(NotificationManager::class.java).notify(2, n)
        } catch (e: SecurityException) {
        }
    }
}

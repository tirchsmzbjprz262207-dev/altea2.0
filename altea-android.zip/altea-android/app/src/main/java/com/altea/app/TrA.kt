package com.altea.app

// Orden: es, en, fr, it, ja, zh, ru
internal val STR_A: Map<String, List<String>> = mapOf(
    // ---- pestañas ----
    "tab_home" to listOf("Inicio", "Home", "Accueil", "Home", "ホーム", "首页", "Главная"),
    "tab_graph" to listOf("Gráfica", "Graph", "Graphique", "Grafico", "グラフ", "图表", "График"),
    "tab_symptoms" to listOf("Síntomas", "Symptoms", "Symptômes", "Sintomi", "症状", "症状", "Симптомы"),
    "tab_history" to listOf("Historial", "History", "Historique", "Cronologia", "履歴", "历史", "История"),
    "tab_custom" to listOf("Personalizar", "Customize", "Personnaliser", "Personalizza", "カスタマイズ", "个性化", "Оформление"),

    // ---- inicio ----
    "pulse" to listOf("Pulso", "Pulse", "Pouls", "Polso", "脈拍", "脉搏", "Пульс"),
    "movement" to listOf("Movimiento", "Movement", "Mouvement", "Movimento", "動き", "活动", "Движение"),
    "tilt" to listOf("Inclinación", "Tilt", "Inclinaison", "Inclinazione", "傾き", "倾斜", "Наклон"),
    "bpm_unit" to listOf(
        "pulsaciones por minuto (bpm)", "beats per minute (bpm)", "battements par minute (bpm)",
        "battiti al minuto (bpm)", "1分あたりの拍数 (bpm)", "每分钟心跳次数 (bpm)", "ударов в минуту (bpm)"
    ),
    "rest" to listOf("Reposo", "Rest", "Repos", "Riposo", "安静", "静止", "Покой"),
    "light" to listOf("Ligero", "Light", "Léger", "Leggero", "軽い", "轻微", "Лёгкое"),
    "intense" to listOf("Intenso", "Intense", "Intense", "Intenso", "激しい", "剧烈", "Интенсивное"),
    "no_data" to listOf("Sin lectura", "No reading", "Pas de mesure", "Nessuna lettura", "測定なし", "无读数", "Нет данных"),

    // ---- conexión ----
    "st_off" to listOf("Sin conexión", "Not connected", "Non connecté", "Non connesso", "未接続", "未连接", "Нет подключения"),
    "st_scan" to listOf("Buscando ALTEA…", "Searching for ALTEA…", "Recherche d'ALTEA…", "Ricerca di ALTEA…", "ALTEAを検索中…", "正在搜索 ALTEA…", "Поиск ALTEA…"),
    "st_conn" to listOf("Conectando…", "Connecting…", "Connexion…", "Connessione…", "接続中…", "正在连接…", "Подключение…"),
    "st_ok" to listOf("Conectado a ALTEA", "Connected to ALTEA", "Connecté à ALTEA", "Connesso ad ALTEA", "ALTEAに接続済み", "已连接 ALTEA", "Подключено к ALTEA"),
    "st_bt_off" to listOf("Bluetooth apagado", "Bluetooth is off", "Bluetooth désactivé", "Bluetooth spento", "Bluetoothがオフです", "蓝牙已关闭", "Bluetooth выключен"),
    "st_lost" to listOf(
        "Desconectado, reconectando…", "Disconnected, reconnecting…", "Déconnecté, reconnexion…",
        "Disconnesso, riconnessione…", "切断されました。再接続中…", "已断开，正在重连…", "Отключено, переподключение…"
    ),
    "st_nosvc" to listOf(
        "La pulsera no responde como se esperaba", "The band is not responding as expected", "Le bracelet ne répond pas comme prévu",
        "Il braccialetto non risponde come previsto", "バンドが想定どおりに応答しません", "手环没有按预期响应", "Браслет отвечает не так, как ожидалось"
    ),
    "btn_connect" to listOf("Conectar pulsera", "Connect band", "Connecter le bracelet", "Collega il braccialetto", "バンドを接続", "连接手环", "Подключить браслет"),
    "btn_disconnect" to listOf("Desconectar", "Disconnect", "Déconnecter", "Disconnetti", "切断", "断开连接", "Отключить"),

    // ---- alertas y mensajes ----
    "alert_title" to listOf("Alerta", "Alert", "Alerte", "Allarme", "警告", "警报", "Тревога"),
    "al_hi" to listOf("Pulso alto: {0} bpm", "High pulse: {0} bpm", "Pouls élevé : {0} bpm", "Polso alto: {0} bpm", "脈拍が高い: {0} bpm", "脉搏过高：{0} bpm", "Высокий пульс: {0} bpm"),
    "al_lo" to listOf("Pulso bajo: {0} bpm", "Low pulse: {0} bpm", "Pouls bas : {0} bpm", "Polso basso: {0} bpm", "脈拍が低い: {0} bpm", "脉搏过低：{0} bpm", "Низкий пульс: {0} bpm"),
    "al_jump" to listOf(
        "Subida brusca de pulso: +{0} bpm", "Sudden pulse rise: +{0} bpm", "Hausse brutale du pouls : +{0} bpm",
        "Aumento improvviso del polso: +{0} bpm", "脈拍の急上昇: +{0} bpm", "脉搏骤升：+{0} bpm", "Резкий рост пульса: +{0} bpm"
    ),
    "al_fall" to listOf("Posible caída", "Possible fall", "Chute possible", "Possibile caduta", "転倒の可能性", "可能跌倒", "Возможное падение"),
    "btn_ok" to listOf("Estoy bien", "I'm OK", "Ça va", "Sto bene", "大丈夫です", "我没事", "Я в порядке"),
    "btn_send_now" to listOf("Enviar ahora", "Send now", "Envoyer maintenant", "Invia ora", "今すぐ送信", "立即发送", "Отправить сейчас"),
    "btn_whatsapp" to listOf("Avisar por WhatsApp", "Notify via WhatsApp", "Prévenir par WhatsApp", "Avvisa su WhatsApp", "WhatsAppで通知", "通过 WhatsApp 通知", "Сообщить в WhatsApp"),
    "countdown" to listOf(
        "Se enviará un mensaje a tu contacto en {0} s si no tocas «Estoy bien»",
        "A message will be sent to your contact in {0} s unless you tap “I'm OK”",
        "Un message sera envoyé à votre contact dans {0} s si vous ne touchez pas « Ça va »",
        "Un messaggio sarà inviato al tuo contatto tra {0} s se non tocchi «Sto bene»",
        "「大丈夫です」を押さないと、{0}秒後に連絡先へメッセージを送信します",
        "如果不点击“我没事”，{0}秒后将向你的联系人发送消息",
        "Через {0} с контакту будет отправлено сообщение, если не нажать «Я в порядке»"
    ),
    "msg_sending" to listOf("Enviando mensaje…", "Sending message…", "Envoi du message…", "Invio del messaggio…", "メッセージを送信中…", "正在发送消息…", "Отправка сообщения…"),
    "msg_sent" to listOf("SMS enviado a {0}", "SMS sent to {0}", "SMS envoyé à {0}", "SMS inviato a {0}", "{0}にSMSを送信しました", "已向 {0} 发送短信", "SMS отправлено на {0}"),
    "msg_fail" to listOf(
        "No se pudo enviar el SMS. Usa WhatsApp.", "Could not send the SMS. Use WhatsApp.", "Impossible d'envoyer le SMS. Utilisez WhatsApp.",
        "Impossibile inviare l'SMS. Usa WhatsApp.", "SMSを送信できませんでした。WhatsAppを使ってください。", "短信发送失败，请使用 WhatsApp。", "Не удалось отправить SMS. Используйте WhatsApp."
    ),
    "no_sms_perm" to listOf(
        "Falta el permiso de SMS. Usa WhatsApp.", "SMS permission is missing. Use WhatsApp.", "Autorisation SMS manquante. Utilisez WhatsApp.",
        "Manca il permesso SMS. Usa WhatsApp.", "SMSの権限がありません。WhatsAppを使ってください。", "缺少短信权限，请使用 WhatsApp。", "Нет разрешения на SMS. Используйте WhatsApp."
    ),
    "no_phone" to listOf(
        "Falta el teléfono de contacto", "The contact phone is missing", "Le téléphone du contact est manquant",
        "Manca il telefono del contatto", "連絡先の電話番号がありません", "缺少联系人电话", "Не указан телефон контакта"
    ),
    "wa_fail" to listOf(
        "No se pudo abrir WhatsApp", "Could not open WhatsApp", "Impossible d'ouvrir WhatsApp",
        "Impossibile aprire WhatsApp", "WhatsAppを開けませんでした", "无法打开 WhatsApp", "Не удалось открыть WhatsApp"
    ),
    "msg_help" to listOf(
        "ALTEA: {0} necesita ayuda. {1}. Pulso: {2} bpm.",
        "ALTEA: {0} needs help. {1}. Pulse: {2} bpm.",
        "ALTEA : {0} a besoin d'aide. {1}. Pouls : {2} bpm.",
        "ALTEA: {0} ha bisogno di aiuto. {1}. Polso: {2} bpm.",
        "ALTEA: 助けが必要です（{0}）。{1}。脈拍: {2} bpm。",
        "ALTEA：{0}需要帮助。{1}。脉搏：{2} bpm。",
        "ALTEA: нужна помощь — {0}. {1}. Пульс: {2} bpm."
    ),
    "msg_loc" to listOf(" Ubicación: {0}", " Location: {0}", " Position : {0}", " Posizione: {0}", " 位置: {0}", " 位置：{0}", " Местоположение: {0}"),
    "msg_noloc" to listOf(
        " (ubicación no disponible)", " (location not available)", " (position indisponible)",
        " (posizione non disponibile)", " （位置情報なし）", "（无法获取位置）", " (местоположение недоступно)"
    ),
    "msg_cond" to listOf(" Antecedentes: {0}.", " Medical history: {0}.", " Antécédents : {0}.", " Anamnesi: {0}.", " 既往歴: {0}。", " 既往病史：{0}。", " Анамнез: {0}."),
    "someone" to listOf("Una persona", "A person", "Une personne", "Una persona", "ある人", "某人", "человек"),

    // ---- síntomas ----
    "sym_dizzy" to listOf("Mareo", "Dizziness", "Étourdissement", "Capogiro", "めまい", "头晕", "Головокружение"),
    "sym_weak" to listOf("Debilidad", "Weakness", "Faiblesse", "Debolezza", "脱力感", "乏力", "Слабость"),
    "sym_palp" to listOf("Palpitaciones", "Palpitations", "Palpitations", "Palpitazioni", "動悸", "心悸", "Сердцебиение"),
    "sym_blur" to listOf("Visión borrosa", "Blurred vision", "Vision floue", "Vista offuscata", "視界のぼやけ", "视物模糊", "Нечёткое зрение"),
    "sym_nausea" to listOf("Náuseas", "Nausea", "Nausées", "Nausea", "吐き気", "恶心", "Тошнота"),
    "sym_faint" to listOf("Casi desmayo", "Near fainting", "Quasi-évanouissement", "Quasi svenimento", "失神しそう", "险些晕厥", "Предобморочное состояние"),
    "sym_other" to listOf("Otro", "Other", "Autre", "Altro", "その他", "其他", "Другое"),
    "sym_title" to listOf("Registrar síntoma", "Log a symptom", "Enregistrer un symptôme", "Registra un sintomo", "症状を記録", "记录症状", "Записать симптом"),
    "sym_what" to listOf("¿Qué sientes?", "What do you feel?", "Que ressentez-vous ?", "Cosa senti?", "どんな症状ですか？", "你有什么感觉？", "Что вы чувствуете?"),
    "intensity" to listOf("Intensidad", "Intensity", "Intensité", "Intensità", "強さ", "强度", "Интенсивность"),
    "note_opt" to listOf("Nota", "Note", "Note", "Nota", "メモ", "备注", "Заметка"),
    "btn_save_sym" to listOf("Guardar síntoma", "Save symptom", "Enregistrer le symptôme", "Salva sintomo", "症状を保存", "保存症状", "Сохранить симптом"),
    "saved" to listOf("Guardado", "Saved", "Enregistré", "Salvato", "保存しました", "已保存", "Сохранено"),

    // ---- gráfica ----
    "graph_title" to listOf("Pulso en tiempo real", "Live pulse", "Pouls en direct", "Polso in tempo reale", "リアルタイム脈拍", "实时脉搏", "Пульс в реальном времени"),
    "graph_wait" to listOf("Esperando datos…", "Waiting for data…", "En attente de données…", "In attesa di dati…", "データ待機中…", "等待数据…", "Ожидание данных…"),
    "normal_range" to listOf("Rango normal", "Normal range", "Plage normale", "Intervallo normale", "正常範囲", "正常范围", "Нормальный диапазон"),

    // ---- historial ----
    "hist_events" to listOf("Eventos", "Events", "Événements", "Eventi", "イベント", "事件", "События"),
    "hist_readings" to listOf("Lecturas", "Readings", "Mesures", "Letture", "測定値", "读数", "Показания"),
    "hist_none" to listOf("Aún no hay registros.", "No records yet.", "Aucun enregistrement.", "Nessun registro.", "記録はまだありません。", "暂无记录。", "Записей пока нет."),
    "btn_share" to listOf("Compartir", "Share", "Partager", "Condividi", "共有", "分享", "Поделиться"),
    "btn_delete_all" to listOf("Borrar todo", "Delete all", "Tout supprimer", "Elimina tutto", "すべて削除", "全部删除", "Удалить всё"),
    "confirm_delete" to listOf(
        "¿Borrar todo el historial?", "Delete the whole history?", "Supprimer tout l'historique ?",
        "Eliminare tutta la cronologia?", "履歴をすべて削除しますか？", "要删除全部历史记录吗？", "Удалить всю историю?"
    ),
    "btn_cancel" to listOf("Cancelar", "Cancel", "Annuler", "Annulla", "キャンセル", "取消", "Отмена"),
    "btn_delete" to listOf("Borrar", "Delete", "Supprimer", "Elimina", "削除", "删除", "Удалить"),
    "see_map" to listOf("Ver ubicación", "View location", "Voir la position", "Vedi posizione", "位置を見る", "查看位置", "Показать место"),
    "ev_alert" to listOf("Alerta", "Alert", "Alerte", "Allarme", "警告", "警报", "Тревога"),
    "ev_symptom" to listOf("Síntoma", "Symptom", "Symptôme", "Sintomo", "症状", "症状", "Симптом"),
    "hr_avg" to listOf("Prom", "Avg", "Moy", "Media", "平均", "平均", "Сред"),
    "hr_min" to listOf("Mín", "Min", "Min", "Min", "最小", "最低", "Мин"),
    "hr_max" to listOf("Máx", "Max", "Max", "Max", "最大", "最高", "Макс")
)

package com.altea.app

data class Settings(
    val onboarded: Boolean = false,
    val lang: String = "es",
    val name: String = "",
    val age: Int = 0,
    val sex: String = "",              // "m", "f", "o" o vacio
    val weightKg: Double = 0.0,
    val heightCm: Int = 0,
    val phone: String = "",
    val contactName: String = "",
    val condHeart: Boolean = false,
    val condHyper: Boolean = false,
    val condDiabetes: Boolean = false,
    val condAsthma: Boolean = false,
    val condOther: String = "",
    val autoLimits: Boolean = true,
    val hrMax: Int = 120,
    val hrMin: Int = 60,
    val jump: Int = 30,
    val fall: Double = 2.5,
    val bandVibrate: Boolean = true,
    val phoneAlert: Boolean = true,
    val autoMsg: Boolean = true,
    val msgDelaySec: Int = 20,
    val updateSec: Int = 2,
    val historyMin: Int = 10,
    val themeMode: String = "auto",    // auto, adult, kid
    val accent: Int = -1,           // -1 = automatico
    val showPulse: Boolean = true,
    val showMove: Boolean = true,
    val showTilt: Boolean = true,
    val showMini: Boolean = true,
    val bgPath: String = "",
    val logoPath: String = "",
    val kidDecor: String = "auto",    // auto, cars, flowers, bugs, games, animals, space
    val notes: String = "",           // cosas importantes que debemos saber (alergias, medicinas...)
    val extraContacts: String = "",   // JSON: contactos adicionales para SMS
    val tgToken: String = "",         // token del bot de Telegram
    val tgChats: String = ""          // JSON: chats de Telegram que reciben los avisos
)

data class Reading(
    val hr: Int = 0,
    val mov: Double = 0.0,     // movimiento promedio en g
    val tilt: Int = 0,         // grados
    val peak: Double = 1.0     // aceleracion maxima en g
)

/** detail es un codigo: "hi:112", "lo:41", "jump:35", "fall" o una clave de sintoma ("sym_dizzy"). */
data class EventRec(
    val t: Long,
    val type: String,          // "alert" o "symptom"
    val detail: String,
    val sev: Int,
    val note: String,
    val hr: Int,
    val mov: Double,
    val lat: Double?,
    val lon: Double?,
    val place: String = ""     // direccion aproximada (si hay internet)
)

/** Una lectura del historial (promedio, minimo y maximo del periodo). */
data class Sample(
    val t: Long,
    val avg: Int,
    val min: Int,
    val max: Int,
    val mov: Double
)

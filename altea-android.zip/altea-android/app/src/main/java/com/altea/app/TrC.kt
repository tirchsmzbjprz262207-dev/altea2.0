package com.altea.app

// Orden: es, en, fr, it, ja, zh, ru
internal val STR_C: Map<String, List<String>> = mapOf(
    "sym_syncope" to listOf("Desmayo", "Fainting", "Évanouissement", "Svenimento", "失神", "晕厥", "Обморок"),
    "cus_decor" to listOf("Dibujos flotantes", "Floating pictures", "Dessins flottants", "Disegni fluttuanti", "浮かぶイラスト", "漂浮图案", "Плавающие картинки"),
    "dec_hint" to listOf(
        "Elige qué dibujos flotan en la pantalla. Solo se ven en el modo infantil.",
        "Choose which pictures float on the screen. They only show in kids mode.",
        "Choisissez les dessins qui flottent à l'écran. Visibles seulement en mode enfant.",
        "Scegli quali disegni fluttuano sullo schermo. Si vedono solo nella modalità bambini.",
        "画面に浮かぶイラストを選びます。子どもモードでのみ表示されます。",
        "选择屏幕上漂浮的图案。仅在儿童模式下显示。",
        "Выберите, какие картинки плавают на экране. Видны только в детском режиме."
    ),
    "dec_auto" to listOf("Automático", "Automatic", "Automatique", "Automatico", "自動", "自动", "Авто"),
    "dec_cars" to listOf("Carritos", "Cars", "Voitures", "Macchinine", "くるま", "小汽车", "Машинки"),
    "dec_flowers" to listOf("Flores", "Flowers", "Fleurs", "Fiori", "はな", "花朵", "Цветы"),
    "dec_bugs" to listOf("Insectos", "Bugs", "Insectes", "Insetti", "むし", "昆虫", "Насекомые"),
    "dec_games" to listOf("Videojuegos", "Video games", "Jeux vidéo", "Videogiochi", "ゲーム", "电子游戏", "Видеоигры"),
    "dec_animals" to listOf("Animalitos", "Animals", "Animaux", "Animali", "どうぶつ", "小动物", "Зверята"),
    "dec_space" to listOf("Espacio", "Space", "Espace", "Spazio", "うちゅう", "太空", "Космос"),
    "f_notes" to listOf(
        "Cosas importantes que debamos saber (alergias, medicinas…)",
        "Important things we should know (allergies, medicines…)",
        "Choses importantes à savoir (allergies, médicaments…)",
        "Cose importanti da sapere (allergie, farmaci…)",
        "知っておくべき大切なこと（アレルギー、薬など）",
        "需要了解的重要信息（过敏、药物等）",
        "Важное, что нужно знать (аллергии, лекарства…)"
    ),
    "tab_custom_s" to listOf("Estilo", "Style", "Style", "Stile", "テーマ", "风格", "Стиль"),
    "no_place" to listOf("Ubicación no disponible", "Location not available", "Position indisponible", "Posizione non disponibile", "位置情報なし", "无法获取位置", "Местоположение недоступно"),
    "tab_quiz" to listOf("Quiz", "Quiz", "Quiz", "Quiz", "クイズ", "问答", "Викторина"),
    "quiz_title" to listOf("Aprende jugando", "Learn by playing", "Apprendre en jouant", "Impara giocando", "遊んで学ぼう", "边玩边学", "Учись, играя"),
    "quiz_q_of" to listOf("Pregunta {0} de {1}", "Question {0} of {1}", "Question {0} sur {1}", "Domanda {0} di {1}", "{1}問中{0}問目", "第 {0} 题，共 {1} 题", "Вопрос {0} из {1}"),
    "quiz_true" to listOf("Verdadero", "True", "Vrai", "Vero", "正しい", "正确", "Верно"),
    "quiz_false" to listOf("Falso", "False", "Faux", "Falso", "誤り", "错误", "Неверно"),
    "quiz_right" to listOf("¡Correcto!", "Correct!", "Correct !", "Corretto!", "正解！", "答对了！", "Правильно!"),
    "quiz_wrong" to listOf("Incorrecto", "Not quite", "Incorrect", "Sbagliato", "不正解", "答错了", "Неверно"),
    "quiz_next" to listOf("Siguiente", "Next", "Suivant", "Avanti", "次へ", "下一题", "Далее"),
    "quiz_done" to listOf("¡Ronda terminada!", "Round finished!", "Manche terminée !", "Round finito!", "ラウンド終了！", "本轮结束！", "Раунд окончен!"),
    "quiz_result" to listOf("Acertaste {0} de {1}", "You got {0} of {1} right", "Vous avez {0} bonnes réponses sur {1}", "Hai indovinato {0} su {1}", "{1}問中{0}問正解", "答对了 {0} / {1} 题", "Правильных ответов: {0} из {1}"),
    "quiz_again" to listOf("Otra ronda", "Another round", "Une autre manche", "Un altro round", "もう一回", "再来一轮", "Ещё раунд"),
    "quiz_note" to listOf(
        "Preguntas informativas: no sustituyen la consulta con un profesional de salud. Disponibles en español e inglés.",
        "Informational questions: they do not replace seeing a health professional. Available in Spanish and English.",
        "Questions informatives : elles ne remplacent pas un professionnel de santé. Disponibles en espagnol et en anglais.",
        "Domande informative: non sostituiscono un professionista sanitario. Disponibili in spagnolo e inglese.",
        "情報提供のための問題で、医療専門家の診察の代わりにはなりません。スペイン語と英語のみ。",
        "题目仅供参考，不能替代医生的诊断。仅提供西班牙语和英语。",
        "Вопросы носят информационный характер и не заменяют врача. Доступны на испанском и английском."
    )
)

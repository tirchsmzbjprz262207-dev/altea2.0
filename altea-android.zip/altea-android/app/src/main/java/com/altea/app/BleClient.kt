package com.altea.app

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import java.util.UUID

private val SERVICE_UUID: UUID = UUID.fromString("6e400001-b5a3-f393-e0a9-e50e24dcca9e")
private val RX_UUID: UUID = UUID.fromString("6e400002-b5a3-f393-e0a9-e50e24dcca9e")   // celular -> pulsera
private val TX_UUID: UUID = UUID.fromString("6e400003-b5a3-f393-e0a9-e50e24dcca9e")   // pulsera -> celular
private val CCCD_UUID: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")

/**
 * Busca la pulsera "ALTEA", se conecta, recibe las lineas "pulso,ax,ay,az"
 * y puede mandarle ordenes de vibracion. Se reconecta solo si se pierde la conexion.
 */
@SuppressLint("MissingPermission")
@Suppress("DEPRECATION")
class BleClient(
    private val ctx: Context,
    private val onLine: (String) -> Unit,
    private val onState: (String, Boolean) -> Unit
) {
    private val adapter = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
    private val handler = Handler(Looper.getMainLooper())
    private var gatt: BluetoothGatt? = null
    private var rx: BluetoothGattCharacteristic? = null
    private var active = false
    private var scanning = false
    private val buf = StringBuilder()

    fun start() {
        active = true
        scan()
    }

    fun stop() {
        active = false
        stopScan()
        handler.removeCallbacksAndMessages(null)
        gatt?.disconnect()
        gatt?.close()
        gatt = null
        rx = null
    }

    fun vibrate(ms: Int) = send("V$ms\n")

    fun setInterval(ms: Int) = send("I$ms\n")

    private fun send(text: String) {
        val c = rx ?: return
        val g = gatt ?: return
        val bytes = text.toByteArray()
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                g.writeCharacteristic(c, bytes, BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE)
            } else {
                c.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                c.value = bytes
                g.writeCharacteristic(c)
            }
        } catch (e: Exception) {
        }
    }

    private fun scan() {
        if (!active || scanning) return
        if (!adapter.isEnabled) {
            onState("st_bt_off", false)
            handler.postDelayed({ scan() }, 5000)
            return
        }
        val scanner = adapter.bluetoothLeScanner
        if (scanner == null) {
            handler.postDelayed({ scan() }, 5000)
            return
        }
        onState("st_scan", false)
        val filter = ScanFilter.Builder().setDeviceName("ALTEA").build()
        val settings = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build()
        scanning = true
        scanner.startScan(listOf(filter), settings, scanCb)
    }

    private fun stopScan() {
        if (!scanning) return
        scanning = false
        try {
            adapter.bluetoothLeScanner?.stopScan(scanCb)
        } catch (e: Exception) {
        }
    }

    private fun connect(device: BluetoothDevice) {
        onState("st_conn", false)
        buf.setLength(0)
        gatt = device.connectGatt(ctx, false, gattCb, BluetoothDevice.TRANSPORT_LE)
    }

    private val scanCb = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            if (!scanning) return
            stopScan()
            connect(result.device)
        }

        override fun onScanFailed(errorCode: Int) {
            scanning = false
            onState("st_scan", false)
            handler.postDelayed({ scan() }, 5000)
        }
    }

    private val gattCb = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                g.discoverServices()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                g.close()
                if (gatt === g) {
                    gatt = null
                    rx = null
                }
                if (active) {
                    onState("st_lost", false)
                    handler.postDelayed({ if (active && gatt == null) scan() }, 2000)
                }
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            val svc = g.getService(SERVICE_UUID)
            if (svc == null) {
                onState("st_nosvc", false)
                return
            }
            val tx = svc.getCharacteristic(TX_UUID)
            rx = svc.getCharacteristic(RX_UUID)
            val cccd = tx?.getDescriptor(CCCD_UUID)
            if (tx == null || cccd == null) {
                onState("st_nosvc", false)
                return
            }
            g.setCharacteristicNotification(tx, true)
            cccd.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            g.writeDescriptor(cccd)
        }

        override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, status: Int) {
            onState("st_ok", true)
        }

        // Android 13 y mas nuevo
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic, value: ByteArray) {
            procesar(value)
        }

        // Android 12 y mas viejo
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            procesar(c.value ?: return)
        }
    }

    private fun procesar(bytes: ByteArray) {
        buf.append(String(bytes))
        var i = buf.indexOf("\n")
        while (i >= 0) {
            val linea = buf.substring(0, i)
            buf.delete(0, i + 1)
            onLine(linea)
            i = buf.indexOf("\n")
        }
    }
}

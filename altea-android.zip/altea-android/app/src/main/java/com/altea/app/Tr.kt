package com.altea.app

/** Traducciones. Orden de cada lista: es, en, fr, it, ja, zh, ru. Los {0}, {1}... se reemplazan con fmt(). */
object Tr {
    val langs = listOf(
        "es" to "Español",
        "en" to "English",
        "fr" to "Français",
        "it" to "Italiano",
        "ja" to "日本語",
        "zh" to "中文",
        "ru" to "Русский"
    )

    private val all: Map<String, List<String>> by lazy { STR_A + STR_B }

    fun get(key: String, lang: String): String {
        var i = langs.indexOfFirst { it.first == lang }
        if (i < 0) i = 0
        val row = all[key] ?: return key
        return if (i < row.size) row[i] else row[0]
    }

    fun fmt(key: String, lang: String, vararg args: Any?): String {
        var s = get(key, lang)
        args.forEachIndexed { i, a -> s = s.replace("{$i}", a.toString()) }
        return s
    }
}

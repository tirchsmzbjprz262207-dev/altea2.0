package com.altea.app

import android.Manifest
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.telephony.SmsManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Aviso al contacto de emergencia: SMS automatico y WhatsApp (el segundo necesita un toque para enviar). */
object Messenger {
    private var job: Job? = null

    private fun lang(): String = Altea.settings.value.lang

    /** Pide la ubicacion y arma el texto del mensaje en el idioma elegido. */
    suspend fun buildText(code: String): String {
        val s = Altea.settings.value
        val l = s.lang
        val loc = Loc.get(Altea.app)
        if (loc != null) {
            Altea.lastLat = loc.latitude
            Altea.lastLon = loc.longitude
        }
        val who = if (s.name.isBlank()) Tr.get("someone", l) else s.name
        val reason = Altea.describe(code, l)
        val hr = Altea.reading.value.hr
        val sb = StringBuilder(Tr.fmt("msg_help", l, who, reason, if (hr > 0) hr.toString() else "--"))
        val la = Altea.lastLat
        val lo = Altea.lastLon
        if (la != null && lo != null) {
            sb.append(Tr.fmt("msg_loc", l, "https://maps.google.com/?q=$la,$lo"))
        } else {
            sb.append(Tr.get("msg_noloc", l))
        }
        val cond = Health.conditionsText(s) { key -> Tr.get(key, l) }
        if (cond.isNotBlank()) sb.append(Tr.fmt("msg_cond", l, cond))
        return sb.toString()
    }

    fun startCountdown(code: String) {
        job?.cancel()
        job = Altea.scope.launch {
            var left = Altea.settings.value.msgDelaySec
            while (left > 0) {
                Altea.msgStatus.value = Tr.fmt("countdown", lang(), left)
                delay(1000)
                left--
            }
            deliver(code)
        }
    }

    fun sendNow() {
        job?.cancel()
        val code = Altea.alertCode.value ?: ""
        job = Altea.scope.launch { deliver(code) }
    }

    fun cancel() {
        job?.cancel()
        job = null
        Altea.msgStatus.value = null
    }

    fun shareWhatsApp(ctx: Context) {
        val code = Altea.alertCode.value ?: ""
        Altea.scope.launch {
            openWhatsApp(ctx, buildText(code))
        }
    }

    private suspend fun deliver(code: String) {
        Altea.msgStatus.value = Tr.get("msg_sending", lang())
        val text = buildText(code)
        sendSms(text)
        if (Altea.foreground) openWhatsApp(Altea.app, text) else notifyWhatsApp(text)
    }

    private fun sendSms(text: String) {
        val s = Altea.settings.value
        if (s.phone.isBlank()) {
            Altea.msgStatus.value = Tr.get("no_phone", s.lang)
            return
        }
        if (ContextCompat.checkSelfPermission(Altea.app, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            Altea.msgStatus.value = Tr.get("no_sms_perm", s.lang)
            return
        }
        try {
            val sms = if (Build.VERSION.SDK_INT >= 31) {
                Altea.app.getSystemService(SmsManager::class.java)
            } else {
                @Suppress("DEPRECATION")
                SmsManager.getDefault()
            }
            sms.sendMultipartTextMessage(s.phone, null, sms.divideMessage(text), null, null)
            Altea.msgStatus.value = Tr.fmt("msg_sent", s.lang, s.phone)
        } catch (e: Exception) {
            Altea.msgStatus.value = Tr.get("msg_fail", s.lang)
        }
    }

    private fun waIntent(text: String): Intent {
        var tel = Altea.settings.value.phone.filter { it.isDigit() }
        if (tel.length == 10) tel = "52$tel"          // numero de Mexico sin lada de pais
        val base = if (tel.isNotEmpty()) "https://wa.me/$tel" else "https://wa.me/"
        val uri = Uri.parse("$base?text=${Uri.encode(text)}")
        return Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    private fun openWhatsApp(ctx: Context, text: String) {
        try {
            ctx.startActivity(waIntent(text))
        } catch (e: Exception) {
            Altea.msgStatus.value = Tr.get("wa_fail", lang())
        }
    }

    /** Con la app en segundo plano Android no deja abrir WhatsApp solo: se avisa con una notificacion. */
    private fun notifyWhatsApp(text: String) {
        val pi = PendingIntent.getActivity(
            Altea.app, 3, waIntent(text), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(Altea.app, Altea.CH_ALERT)
            .setSmallIcon(android.R.drawable.ic_dialog_email)
            .setContentTitle(Tr.get("btn_whatsapp", lang()))
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        try {
            Altea.app.getSystemService(NotificationManager::class.java).notify(3, n)
        } catch (e: SecurityException) {
        }
    }
}

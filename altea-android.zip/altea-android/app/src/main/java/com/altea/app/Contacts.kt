package com.altea.app

import org.json.JSONArray
import org.json.JSONObject

/** Un contacto: name = nombre, value = telefono (SMS) o id de chat (Telegram). */
data class Person(val name: String, val value: String)

object Contacts {
    fun parse(json: String): List<Person> {
        return try {
            val a = JSONArray(if (json.isBlank()) "[]" else json)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                Person(o.optString("n"), o.optString("v"))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun toJson(list: List<Person>): String {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("n", it.name).put("v", it.value)) }
        return a.toString()
    }

    /** Todos los numeros a los que se manda SMS: el principal y los adicionales, sin repetir. */
    fun smsNumbers(s: Settings): List<String> {
        val all = listOf(s.phone) + parse(s.extraContacts).map { it.value }
        return all.map { it.trim() }.filter { it.isNotBlank() }.distinct()
    }
}

package com.altea.app

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

private val SYMPTOMS = listOf("sym_dizzy", "sym_weak", "sym_palp", "sym_blur", "sym_nausea", "sym_faint", "sym_syncope",
    "sym_sweat", "sym_tremor", "sym_headache", "sym_breath", "sym_chest", "sym_fatigue", "sym_focus", "sym_hot", "sym_other")

// ---------------- SINTOMAS ----------------

@Composable
fun SymptomsScreen() {
    var sel by remember { mutableStateOf(setOf<String>()) }
    var sev by remember { mutableStateOf(3f) }
    var note by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf(false) }
    val pal = LocalPal.current

    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(t("sym_title"), fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Panel {
            Text(t("sym_what"))
            Spacer(Modifier.height(8.dp))
            Text(t("sym_multi"), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(6.dp))
            MultiChips(SYMPTOMS.map { it to t(it) }, sel) { k ->
                sel = if (k in sel) sel - k else sel + k
                saved = false
            }
            if ("sym_chest" in sel || "sym_breath" in sel) {
                Spacer(Modifier.height(8.dp))
                Text(t("sym_urgent"), color = pal.danger, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            }
            Spacer(Modifier.height(12.dp))
            Text(t("intensity") + ": " + sev.roundToInt() + " / 5")
            Slider(value = sev, onValueChange = { sev = it }, valueRange = 1f..5f, steps = 3)
            OutlinedTextField(
                value = note, onValueChange = { note = it },
                label = { Text(t("note_opt")) }, modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            Button(
                enabled = sel.isNotEmpty(),
                onClick = {
                    // se guardan en el orden de la lista, separados por "+"
                    val code = SYMPTOMS.filter { it in sel }.joinToString("+")
                    Altea.addEvent("symptom", code, sev.roundToInt(), note.trim())
                    sel = emptySet()
                    note = ""
                    saved = true
                }
            ) { Text(t("btn_save_sym")) }
            if (saved) Text(t("saved"), color = pal.accent, modifier = Modifier.padding(top = 8.dp))
        }
    }
}

// ---------------- HISTORIAL ----------------

@Composable
fun HistoryScreen() {
    val ev by Altea.events.collectAsState()
    val sm by Altea.samples.collectAsState()
    val ctx = LocalContext.current
    var tab by remember { mutableStateOf("events") }
    var confirm by remember { mutableStateOf(false) }
    val empty = if (tab == "events") ev.isEmpty() else sm.isEmpty()

    Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(t("tab_history"), fontSize = 22.sp, fontWeight = FontWeight.Bold)
        ChoiceChips(listOf("events" to t("hist_events"), "readings" to t("hist_readings")), tab) { tab = it }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                val i = Intent(Intent.ACTION_SEND)
                i.type = "text/plain"
                i.putExtra(Intent.EXTRA_SUBJECT, "ALTEA")
                i.putExtra(Intent.EXTRA_TEXT, Altea.csv())
                ctx.startActivity(Intent.createChooser(i, t2("btn_share")))
            }) { Text(t("btn_share")) }
            OutlinedButton(onClick = { confirm = true }) { Text(t("btn_delete_all")) }
        }
        if (empty) Text(t("hist_none"), color = MaterialTheme.colorScheme.onSurfaceVariant)
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (tab == "events") {
                items(ev.take(150)) { e -> EventRow(e) }
            } else {
                items(sm.take(300)) { x -> SampleRow(x) }
            }
        }
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text(t("confirm_delete")) },
            confirmButton = { TextButton(onClick = { Altea.clearHistory(); confirm = false }) { Text(t("btn_delete")) } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text(t("btn_cancel")) } }
        )
    }
}

/** Texto traducido fuera de un bloque composable. */
private fun t2(key: String): String = Altea.tr(key)

@Composable
fun EventRow(e: EventRec) {
    val ctx = LocalContext.current
    val lang = LocalLang.current
    val pal = LocalPal.current
    val date = SimpleDateFormat("EEEE dd/MM/yyyy HH:mm:ss", Locale(lang)).format(Date(e.t))
        .replaceFirstChar { it.uppercase() }
    val isAlert = e.type == "alert"
    val kind = if (isAlert) t("ev_alert") else t("ev_symptom")
    val sev = if (e.sev > 0) " (" + e.sev + "/5)" else ""
    val pulse = if (e.hr > 0) e.hr.toString() else "--"
    Panel {
        Text(
            kind + ": " + Altea.describe(e.detail, lang) + sev,
            fontWeight = FontWeight.SemiBold,
            color = if (isAlert) pal.danger else pal.text
        )
        val extra = if (e.note.isNotBlank()) " · " + e.note else ""
        Text(
            date + " · " + pulse + " bpm · " + "%.2f g".format(e.mov) + extra,
            fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        val lugar = when {
            e.place.isNotBlank() -> e.place
            e.lat != null && e.lon != null -> "%.5f, %.5f".format(e.lat, e.lon)
            else -> t("no_place")
        }
        if (isAlert) Text("📍 " + lugar, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (e.lat != null && e.lon != null) {
            TextButton(onClick = {
                try {
                    ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + e.lat + "," + e.lon + "(ALTEA)")))
                } catch (ex: ActivityNotFoundException) {
                    Toast.makeText(ctx, "Maps", Toast.LENGTH_SHORT).show()
                }
            }) { Text(t("see_map")) }
        }
    }
}

@Composable
fun SampleRow(x: Sample) {
    val date = SimpleDateFormat("EEE dd/MM/yyyy HH:mm", Locale(LocalLang.current)).format(Date(x.t))
    Panel {
        Text(date, fontWeight = FontWeight.SemiBold)
        Text(
            t("hr_avg") + " " + x.avg + " · " + t("hr_min") + " " + x.min + " · " + t("hr_max") + " " + x.max + " bpm · " +
                t("movement") + " " + "%.2f g".format(x.mov),
            fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

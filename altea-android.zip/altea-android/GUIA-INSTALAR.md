# ALTEA v2: cómo actualizar (paso a paso)

Solo hay **dos cosas** que poner: el **zip** en GitHub (compila la app) y el **main.py** en la pulsera (con Thonny).
No hay que borrar nada en GitHub.

## Parte 1. Subir el zip nuevo a GitHub

1. Entra a tu repositorio en github.com.
2. Toca **Add file** > **Upload files**.
3. Arrastra el archivo **`altea-android.zip`** (sin descomprimir). Se llama igual que el anterior, así que lo reemplaza solo.
4. Baja y toca **Commit changes**.
5. Entra a **Actions**, toca la fila nueva y espera la palomita verde (5 a 10 minutos).
   Si sale una X roja, abre el paso que falló, copia el error y mándamelo.
6. En la página principal del repositorio, a la derecha, toca **Releases** y la versión más nueva. Descarga `app-debug.apk`.

## Parte 2. Instalar la app en el celular

1. **Desinstala la ALTEA anterior** (una sola vez): mantén presionado su ícono > Desinstalar.
   Es necesario porque la versión vieja estaba firmada distinto. Las siguientes versiones ya se instalan encima, sin desinstalar.
2. Pasa el APK nuevo al celular (WhatsApp a ti mismo, cable o descargándolo desde github.com en el navegador del celular) y ábrelo.
3. Android pide permiso para instalar apps de esa fuente: actívalo. Si sale el aviso de Play Protect, toca **Instalar de todos modos**.
4. Abre ALTEA. La primera vez te pide el **teléfono de contacto** (obligatorio) y tu **edad**, y luego los permisos. Acepta todos.
5. Entra al tornillo ⚙ (arriba a la izquierda) > **Permisos de salud y sensores** y revisa que todo diga "Concedido".
   El de **Segundo plano (sin límite de batería)** es importante: acéptalo para que Android no cierre la app con la pantalla bloqueada.
6. Si tu celular es Android 11 o más viejo, deja **encendida la Ubicación** del celular (el interruptor del panel rápido), porque Android la pide para buscar la pulsera por Bluetooth.

## Parte 3. Cargar el main.py nuevo en la pulsera (Thonny)

1. Conecta la ESP32-C3 a la computadora y abre **Thonny**.
2. Abre el archivo **`main.py`** nuevo (viene en este zip, en la carpeta `firmware`).
3. Toca **File > Save as...**, elige **MicroPython device** y guárdalo con el nombre **`main.py`**. Si pregunta si reemplazar, di que sí.
4. Reinicia la ESP32 (botón reset o desconéctala y conéctala). La pantalla OLED debe decir "ALTEA".
5. En la app, toca **Conectar pulsera**.

La app nueva necesita este `main.py` nuevo: cambió el formato de los datos.

## Cómo usarla

- **Deslizar a la izquierda** cambia de pantalla: Inicio, Gráfica en tiempo real, Síntomas, Historial y Personalizar.
- **⚙ arriba a la izquierda**: idioma, contacto, datos personales, antecedentes de salud, alertas, intervalos y permisos.
- **Personalizar**: tema (adulto o infantil), color, fondo de pantalla, logo y qué paneles se ven en Inicio.
- Si hay una alerta, la app vibra, la pulsera vibra y empieza una cuenta regresiva. Si no tocas **Estoy bien**, manda un **SMS** con tu pulso y tu ubicación y abre **WhatsApp** con el mensaje listo (solo falta tocar enviar: Android no deja que ninguna app envíe WhatsApp sola).

## Play Store (para más adelante)

- Cuenta de desarrollador: 25 USD, pago único.
- Cuenta personal nueva: prueba cerrada con al menos 12 personas durante 14 días seguidos antes de publicar.
- Se sube un `.aab` firmado con una llave propia (no el APK de prueba).
- El permiso de SMS automático está restringido en Play: hay una excepción para alertas de emergencia, pero requiere formulario y aprobación. Lo más seguro para Play es quitar `SEND_SMS` y avisar solo por WhatsApp.
- Pide política de privacidad (datos de salud y ubicación) y aviso de que no es dispositivo médico.
- Si el logo lo bajaste de internet, revisa que puedas usarlo si algún día publicas la app.

## Si algo sale mal

- Manda captura o el mensaje de error (de GitHub Actions o de la app).
- Todo el código está también en `ALTEA-codigo-completo.txt` como respaldo.

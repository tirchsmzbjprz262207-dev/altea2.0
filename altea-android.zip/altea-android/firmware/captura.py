# ALTEA - captura de la senal cruda del sensor de pulso (para diagnostico)
# Uso: en Thonny abre este archivo y toca "Run current script" (el botoncito verde).
# NO lo guardes en la ESP32 como main.py. Apoya el dedo en el sensor cuando diga "PON EL DEDO".
# Al terminar copia TODO lo que salga en la consola y mandamelo.

from machine import Pin, SoftI2C
from time import sleep_ms, ticks_ms, ticks_diff

i2c = SoftI2C(sda=Pin(0), scl=Pin(1), freq=400000)
A = 0x57


def w(reg, val):
    i2c.writeto_mem(A, reg, bytes([val]))


def r(reg):
    return i2c.readfrom_mem(A, reg, 1)[0]


w(0x09, 0x40)
sleep_ms(100)
w(0x08, 0x1F)
w(0x09, 0x03)
w(0x0A, 0x27)
w(0x0C, 0x24)
w(0x0D, 0x24)
for reg in (0x04, 0x05, 0x06):
    w(reg, 0)


def leer():
    n = (r(0x04) - r(0x06)) & 0x1F
    out = []
    if n:
        d = i2c.readfrom_mem(A, 0x07, n * 6)
        for i in range(n):
            b = i * 6 + 3
            out.append(((d[b] << 16) | (d[b + 1] << 8) | d[b + 2]) & 0x3FFFF)
    return out


print("PON EL DEDO en el sensor y no te muevas...")
while True:
    m = leer()
    if m and m[-1] > 30000:
        break
    sleep_ms(20)

print("CAPTURANDO 20 segundos, no te muevas")
datos = []
t0 = ticks_ms()
while ticks_diff(ticks_ms(), t0) < 20000:
    datos.extend(leer())
    sleep_ms(5)
ms = ticks_diff(ticks_ms(), t0)

print("FIN. muestras:", len(datos), "ms:", ms, "muestras por segundo:", round(len(datos) * 1000 / ms, 1))
print("===== COPIA DESDE AQUI =====")
for i in range(0, len(datos), 25):
    print(",".join(str(v) for v in datos[i:i + 25]))
print("===== HASTA AQUI =====")

# ALTEA v2.1 - firmware para ESP32-C3 mini (MicroPython)
# Une tu codigo (pantalla y pulso) con el Bluetooth para la app.
# Sensores: MAX30102 (pulso), MPU6050 (movimiento), OLED SSD1306, motor vibrador
#
# Pulsera -> celular (BLE, una linea cada "intervalo"):  A,pulso,mov,incl,pico\n
#     pulso = latidos por minuto (0 si no hay lectura)
#     mov   = movimiento promedio en centesimas de g
#     incl  = inclinacion en grados
#     pico  = aceleracion maxima del periodo en centesimas de g (sirve para detectar caidas)
# Celular -> pulsera:  V<ms>  vibra el motor (V0 lo apaga)   |   I<ms>  cambia el intervalo (500 a 10000)

from machine import Pin, SoftI2C
from time import sleep_ms, ticks_ms, ticks_diff
import framebuf
import bluetooth
import math

# ---------------- CONFIGURACION (tus pines) ----------------
PIN_SDA = 0
PIN_SCL = 1
PIN_MOTOR = 10
NOMBRE_BLE = "ALTEA"
MPU_ADDR = 0x68
MAX_ADDR = 0x57
OLED_ADDR = 0x3C
IR_MINIMO = 30000          # debajo de esto no hay dedo/muneca puesta

# Zonas de pulso (latidos por minuto)
NORMAL_MIN = 70      # 70 a 100  -> NORMAL
NORMAL_MAX = 100
LIMITE_MIN = 60      # 60 a 69 y 101 a 120 -> LIMITE (triangulo parpadea lento)
LIMITE_MAX = 120     # menos de 60 o mas de 120 -> PELIGRO (triangulo rapido + vibra)


def zona(bpm):
    """0 = sin lectura, 1 = normal, 2 = limite, 3 = peligro"""
    if bpm <= 0:
        return 0
    if NORMAL_MIN <= bpm <= NORMAL_MAX:
        return 1
    if LIMITE_MIN <= bpm <= LIMITE_MAX:
        return 2
    return 3

i2c = SoftI2C(sda=Pin(PIN_SDA), scl=Pin(PIN_SCL), freq=400000)
motor = Pin(PIN_MOTOR, Pin.OUT, value=0)


# ---------------- Pantalla OLED (no necesita la libreria ssd1306) ----------------
class OLED(framebuf.FrameBuffer):
    def __init__(self, i2c, address=OLED_ADDR):
        self.i2c = i2c
        self.address = address
        self.buffer = bytearray(1024)
        super().__init__(self.buffer, 128, 64, framebuf.MONO_VLSB)
        for c in (0xAE, 0x20, 0x00, 0x40, 0xA1, 0xC8, 0x81, 0x7F, 0xA6,
                  0xA8, 0x3F, 0xD3, 0x00, 0xD5, 0x80, 0xD9, 0xF1, 0xDA,
                  0x12, 0xDB, 0x40, 0x8D, 0x14, 0xAF):
            self.command(c)

    def command(self, value):
        self.i2c.writeto(self.address, bytes([0x00, value]))

    def show(self):
        for c in (0x21, 0, 127, 0x22, 0, 7):
            self.command(c)
        self.i2c.writeto(self.address, b"\x40" + self.buffer)


def texto_grande(oled, s, x, y, k):
    """Escribe texto agrandado k veces (para el numero de BPM)."""
    tmp = bytearray(8)
    fb = framebuf.FrameBuffer(tmp, 8, 8, framebuf.MONO_VLSB)
    for i, ch in enumerate(s):
        fb.fill(0)
        fb.text(ch, 0, 0, 1)
        for col in range(8):
            for fila in range(8):
                if fb.pixel(col, fila):
                    oled.fill_rect(x + (i * 8 + col) * k, y + fila * k, k, k, 1)


FIGURA_CORAZON = ("01100110", "11111111", "11111111", "11111111",
                  "01111110", "00111100", "00011000")


def corazon(oled, x, y, lleno):
    for fila in range(7):
        for col in range(8):
            if FIGURA_CORAZON[fila][col] == "1":
                if lleno:
                    borde = True
                else:
                    borde = (fila == 0 or fila == 6 or col == 0 or col == 7
                             or FIGURA_CORAZON[fila][col - 1] == "0"
                             or FIGURA_CORAZON[fila][col + 1] == "0")
                if borde:
                    oled.fill_rect(x + col * 2, y + fila * 2, 2, 2, 1)


def triangulo(oled, x, y):
    oled.line(x + 8, y, x, y + 14, 1)
    oled.line(x + 8, y, x + 16, y + 14, 1)
    oled.line(x, y + 14, x + 16, y + 14, 1)
    oled.vline(x + 8, y + 4, 5, 1)
    oled.pixel(x + 8, y + 11, 1)


def dibujar_pantalla(oled, bpm, estado, onda, latido, conectado, tri):
    """Arriba: ALTEA. Enmedio: BPM grande. Abajo: grafica de pulsaciones."""
    oled.fill(0)
    oled.text("ALTEA", 0, 4)
    if conectado:
        oled.text("BT", 56, 4)
    corazon(oled, 110, 0, latido)
    if tri:
        triangulo(oled, 86, 0)
    oled.hline(0, 16, 128, 1)

    texto_grande(oled, str(bpm) if bpm else "--", 0, 19, 3)
    oled.text("BPM", 76, 21)
    oled.text(estado, 76, 33)

    oled.hline(0, 44, 128, 1)
    for x in range(127):
        oled.line(x, 54 - onda[x], x + 1, 54 - onda[x + 1], 1)
    oled.show()


# ---------------- Sensores ----------------
def leer_mpu():
    d = i2c.readfrom_mem(MPU_ADDR, 0x3B, 6)
    v = []
    for i in range(0, 6, 2):
        n = (d[i] << 8) | d[i + 1]
        if n > 32767:
            n -= 65536
        v.append(n / 16384)
    return v


class MAX30102:
    def __init__(self, i2c, addr=MAX_ADDR):
        self.i2c = i2c
        self.a = addr
        self.w(0x09, 0x40)          # reiniciar
        sleep_ms(100)
        self.w(0x08, 0x1F)          # sin promedio (muestra cruda)
        self.w(0x09, 0x03)          # modo rojo + infrarrojo
        self.w(0x0A, 0x27)          # 100 muestras por segundo, 411 us, 18 bits
        self.w(0x0C, 0x24)          # corriente LED rojo
        self.w(0x0D, 0x24)          # corriente LED infrarrojo
        for r in (0x04, 0x05, 0x06):
            self.w(r, 0)

    def w(self, reg, val):
        self.i2c.writeto_mem(self.a, reg, bytes([val]))

    def r(self, reg):
        return self.i2c.readfrom_mem(self.a, reg, 1)[0]

    def muestras_ir(self):
        n = (self.r(0x04) - self.r(0x06)) & 0x1F
        out = []
        if n:
            d = self.i2c.readfrom_mem(self.a, 0x07, n * 6)
            for i in range(n):
                b = i * 6 + 3
                out.append(((d[b] << 16) | (d[b + 1] << 8) | d[b + 2]) & 0x3FFFF)
        return out


def mediana(lista):
    s = sorted(lista)
    return s[len(s) // 2]


K_UMBRAL = 0.4
K_ESTABLE = 0.05
K_MINAMP = 60          # senal mas debil que esto (en cuentas del sensor) se considera ruido
K_REARME = 1.0


class Pulso:
    """Detector de latidos: quita la luz base, filtra, cuenta cada vez que la senal sube
    de negativo a positivo (funciona aunque la senal venga al reves), descarta lecturas raras."""

    MINIMO = 30000      # debajo de esto no hay dedo/muneca puesta

    def __init__(self):
        self.reset()

    def reset(self):
        self.dc = 0
        self.lp = 0
        self.s = 0
        self.buf = []
        self.n = 0
        self.ult = []
        self.listo = False
        self.k = 0
        self.sd = 0
        self.pk = 20
        self.m3 = 0
        self.bajo = 0
        self.t_ac = 0
        self.amp = 0
        self.armado = True
        self.cal = 25
        self.ultimo = None
        self.intervalos = []
        self.rechazos = 0
        self.cand = 0
        self.bpm = 0
        self.latido_t = -10000

    def agregar(self, ir, t):
        """ir = muestra infrarroja, t = instante en ms. Devuelve los BPM (0 si aun no hay)."""
        if ir < self.MINIMO:
            if self.dc:
                self.reset()
            return 0
        # al poner el dedo la luz cambia mucho unos instantes: se espera a que se estabilice
        # (rango pequeno en los ultimos 0.2 s) y entonces se empieza a medir de inmediato
        if not self.listo:
            self.dc = ir
            self.ult.append(ir)
            if len(self.ult) > 20:
                self.ult.pop(0)
            if len(self.ult) >= 20 and max(self.ult) - min(self.ult) < ir * K_ESTABLE:
                self.listo = True
                self.dc = sum(self.ult) // len(self.ult)
                self.lp = 0
                self.cal = 6
            else:
                return 0
        self.dc += (ir - self.dc) * (0.06 if self.k < 100 else 0.04)
        x = ir - self.dc
        self.lp += (x - self.lp) * 0.15
        self.k += 1
        self.s = self.lp
        # senal limpia solo para dibujar la grafica
        self.sd += (self.lp - self.sd) * 0.12
        self.m3 += (self.sd * self.sd * self.sd - self.m3) * 0.002
        self.pk = max(abs(self.sd), self.pk * 0.9995, 20)
        h = max(self.amp * K_UMBRAL, K_MINAMP * 0.5)
        self.n += 1
        if self.n % 4 == 0:                    # copia a 25 por segundo para la revision de ritmo
            self.buf.append(int(self.lp))
            if len(self.buf) > 150:
                self.buf.pop(0)
            seg = self.buf[-40:]                # amplitud de la ultima 1.6 s (se recupera rapido de golpes)
            self.amp = (max(seg) - min(seg)) / 2 if len(seg) >= 10 else 0
            self.revisar(t)

        if self.cal > 0:
            self.cal -= 1                      # primeros 0.25 s: solo se asienta el filtro
        elif self.lp < -h * K_REARME:
            self.armado = True
        elif self.armado and self.lp > h:
            self.armado = False
            self.latido(t)

        if self.ultimo is not None and ticks_diff(t, self.ultimo) > 5000:
            self.bpm = 0
            self.intervalos = []
            self.ultimo = None
        return self.bpm

    def punto_grafica(self):
        """Valor de -8 a 8 para la grafica: suave y siempre con el latido hacia arriba."""
        v = self.sd / self.pk * 8
        if self.m3 < 0:
            v = -v
        return max(-8, min(8, int(v)))

    def ritmo_global(self):
        """Mira la senal reciente (hasta 6 s) y calcula el ritmo general con una autocorrelacion."""
        x = self.buf
        n = len(x)
        den = 0
        for v in x:
            den += v * v
        if den == 0:
            return 0
        r = {}
        for lag in range(8, 35):
            a = 0
            for i in range(n - lag):
                a += x[i] * x[i + lag]
            r[lag] = a / den
        mejor = max(r.values())
        if mejor < 0.3:
            return 0
        # el lag mas corto que sea un maximo local y casi tan fuerte como el mejor
        for lag in range(9, 34):
            if r[lag] > r[lag - 1] and r[lag] >= r[lag + 1] and r[lag] >= mejor * 0.85:
                den2 = r[lag - 1] - 2 * r[lag] + r[lag + 1]
                d = 0.5 * (r[lag - 1] - r[lag + 1]) / den2 if den2 else 0
                return int(1500 / (lag + d) + 0.5)   # 25 muestras/s * 60 / lag
        return 0

    def revisar(self, t):
        """Corrige el ritmo si la revision global no coincide con lo contado latido por latido."""
        if len(self.buf) < 75 or ticks_diff(t, self.t_ac) < 1000 or self.amp < K_MINAMP:
            return
        self.t_ac = t
        g = self.ritmo_global()
        if not g:
            return
        if not self.intervalos:
            if self.bpm == 0 and len(self.buf) >= 100:   # los latidos sueltos no se detectaron: usar el ritmo global
                self.intervalos = [int(60000 / g)] * 3
                self.bpm = g
            return
        cur = 60000 / mediana(self.intervalos)
        if abs(cur - g) > g * 0.12:
            self.intervalos = [int(60000 / g)] * 3
            self.bpm = g
            self.rechazos = 0

    def latido(self, t):
        if self.ultimo is None:
            self.ultimo = t
            self.latido_t = t
            return
        dt = ticks_diff(t, self.ultimo)
        med = mediana(self.intervalos) if self.intervalos else 0
        if dt < 300 or (med and dt < med * 0.6):
            return                             # latido de mas (muesca de la onda): se ignora
        self.ultimo = t
        self.latido_t = t
        if med:
            r = dt / med
            if 1.7 <= r <= 2.3:                # se escapo un latido: este intervalo vale por 2
                dt = dt // 2
            elif 2.6 <= r <= 3.4:              # se escaparon dos
                dt = dt // 3
            elif abs(r - 1) > 0.25:            # intervalo raro: se descarta
                self.rechazos += 1
                if self.rechazos >= 3:         # si siguen raros, el ritmo cambio de verdad
                    self.intervalos = []
                    self.cand = 0
                    self.rechazos = 0
                return
        elif dt > 1800:                        # senal perdida, empezar de nuevo
            self.cand = 0
            return
        else:
            # al empezar se espera a ver dos intervalos parecidos antes de mostrar un numero
            if self.cand and abs(dt - self.cand) < self.cand * 0.2:
                self.intervalos = [self.cand]
            else:
                self.cand = dt
                return
        self.rechazos = 0
        self.intervalos.append(dt)
        self.intervalos = self.intervalos[-5:]
        objetivo = 60000 / mediana(self.intervalos)
        if objetivo < 50:
            # un pulso menor de 50 casi siempre es un latido que no se detecto:
            # solo se acepta si la revision de ritmo lo confirma o si dura muchos latidos
            self.bajo += 1
            g = self.ritmo_global() if len(self.buf) >= 100 else 0
            if not (g and abs(g - objetivo) <= objetivo * 0.15) and self.bajo < 8:
                return
        else:
            self.bajo = 0
        if self.bpm == 0:
            self.bpm = int(objetivo)
        else:
            nuevo = int(self.bpm * 0.5 + objetivo * 0.5 + 0.5)
            # el pulso real no salta de golpe: maximo 5 bpm de cambio por latido
            self.bpm = max(self.bpm - 5, min(self.bpm + 5, nuevo))


# ---------------- Bluetooth LE ----------------
UUID_SERVICIO = bluetooth.UUID("6E400001-B5A3-F393-E0A9-E50E24DCCA9E")
UUID_RX = bluetooth.UUID("6E400002-B5A3-F393-E0A9-E50E24DCCA9E")
UUID_TX = bluetooth.UUID("6E400003-B5A3-F393-E0A9-E50E24DCCA9E")

ble = bluetooth.BLE()
ble.active(True)
((h_tx, h_rx),) = ble.gatts_register_services((
    (UUID_SERVICIO, (
        (UUID_TX, bluetooth.FLAG_NOTIFY),
        (UUID_RX, bluetooth.FLAG_WRITE | bluetooth.FLAG_WRITE_NO_RESPONSE),
    )),
))

conexion = None
vibrar_hasta = 0
intervalo_ms = 2000


def publicitar():
    n = NOMBRE_BLE.encode()
    ble.gap_advertise(100000, adv_data=bytes([2, 0x01, 0x06, len(n) + 1, 0x09]) + n)


def irq(evento, datos):
    global conexion, vibrar_hasta, intervalo_ms
    if evento == 1:
        conexion = datos[0]
    elif evento == 2:
        conexion = None
        publicitar()
    elif evento == 3:
        try:
            msg = ble.gatts_read(h_rx).decode().strip()
            n = int(msg[1:])
        except (ValueError, UnicodeError):
            return
        if msg[0] == "V":
            vibrar_hasta = ticks_ms() + n if n > 0 else 0
        elif msg[0] == "I":
            intervalo_ms = min(10000, max(500, n))


ble.irq(irq)
publicitar()


def enviar(texto):
    if conexion is not None:
        try:
            ble.gatts_notify(conexion, h_tx, texto.encode())
        except OSError:
            pass


# ---------------- Arranque ----------------
print("ALTEA v2.1 - INICIANDO")
dispositivos = i2c.scan()
print("I2C encontrados:", [hex(d) for d in dispositivos])
pantalla = None
if OLED_ADDR in dispositivos:
    try:
        pantalla = OLED(i2c)
        pantalla.fill(0)
        pantalla.text("ALTEA", 40, 28)
        pantalla.show()
    except OSError:
        pantalla = None

mpu_ok = MPU_ADDR in dispositivos
if mpu_ok:
    try:
        i2c.writeto_mem(MPU_ADDR, 0x6B, b"\x00")
        sleep_ms(100)
    except OSError:
        mpu_ok = False

sensor = None
if MAX_ADDR in dispositivos:
    try:
        sensor = MAX30102(i2c)
    except OSError:
        sensor = None

pulso = Pulso()
bpm = 0
ax = ay = 0.0
az = 1.0
suma_mov = 0.0
n_mov = 0
pico = 1.0
onda = [0] * 128
t_onda = ticks_ms()
fuera_desde = None
t_envio = ticks_ms()
t_mpu = ticks_ms()
t_dibujo = ticks_ms()
cnt_muestras = 0
t_cnt = ticks_ms()
ms_muestra = 10.0
t_debug = ticks_ms()

# ---------------- Bucle principal ----------------
while True:
    ahora = ticks_ms()

    # ---- pulso: se leen todas las muestras que haya y se les reparte la hora ----
    if sensor:
        try:
            muestras = sensor.muestras_ir()
            n = len(muestras)
            cnt_muestras += n
            for i in range(n):
                bpm = pulso.agregar(muestras[i], int(ahora - (n - 1 - i) * ms_muestra))
            # mide la velocidad real a la que llegan las muestras (para que los BPM sean exactos)
            dt_cnt = ticks_diff(ahora, t_cnt)
            if dt_cnt >= 3000:
                if cnt_muestras >= 100:
                    ms_muestra = min(50.0, max(4.0, dt_cnt / cnt_muestras))
                cnt_muestras = 0
                t_cnt = ahora
        except OSError:
            pass

    # ---- zona de pulso y motor ----
    z = zona(bpm)
    if z == 3:
        if fuera_desde is None:
            fuera_desde = ahora
    else:
        fuera_desde = None
    # peligro sostenido 3 segundos: vibra 250 ms cada segundo
    peligro = fuera_desde is not None and ticks_diff(ahora, fuera_desde) > 3000
    vibra_local = peligro and ahora % 1000 < 250
    motor.value(1 if (ticks_diff(vibrar_hasta, ahora) > 0 or vibra_local) else 0)

    # ---- acelerometro a ~50 Hz: promedio de movimiento y pico ----
    if mpu_ok and ticks_diff(ahora, t_mpu) >= 20:
        t_mpu = ahora
        try:
            ax, ay, az = leer_mpu()
            mag = math.sqrt(ax * ax + ay * ay + az * az)
            suma_mov += abs(mag - 1)
            n_mov += 1
            if mag > pico:
                pico = mag
        except OSError:
            pass

    # ---- puntos de la grafica (20 por segundo) ----
    if ticks_diff(ahora, t_onda) >= 50:
        t_onda = ahora
        onda.pop(0)
        onda.append(pulso.punto_grafica() if pulso.dc else 0)

    # ---- pantalla (10 veces por segundo) ----
    if pantalla and ticks_diff(ahora, t_dibujo) >= 100:
        t_dibujo = ahora
        if pulso.dc == 0:
            estado = ""
        else:
            estado = ("MIDE..", "NORMAL", "LIMITE", "ALERTA")[z]
        if bpm:
            periodo = 60000 // bpm
            latido = ticks_diff(ahora, pulso.latido_t) % periodo < periodo * 0.4
        else:
            latido = False
        if z == 2:
            tri = ahora % 1600 < 900          # parpadeo lento
        elif z == 3:
            tri = ahora % 400 < 200           # parpadeo rapido
        else:
            tri = False
        try:
            dibujar_pantalla(pantalla, bpm, estado, onda, latido, conexion is not None, tri)
        except OSError:
            pass

    # ---- informacion para revisar en Thonny (una vez por segundo) ----
    if sensor and ticks_diff(ahora, t_debug) >= 1000:
        t_debug = ahora
        print("dedo:", pulso.dc > 0, "listo:", pulso.listo, "luz:", int(pulso.dc), "amp:", int(pulso.amp), "ms/muestra:", round(ms_muestra, 1), "intervalos:", pulso.intervalos, "bpm:", bpm)

    # ---- envio al celular ----
    if ticks_diff(ahora, t_envio) >= intervalo_ms:
        t_envio = ahora
        mov = (suma_mov / n_mov) if n_mov else 0
        mag = math.sqrt(ax * ax + ay * ay + az * az)
        incl = int(math.degrees(math.acos(max(-1, min(1, az / mag))))) if mag > 0.1 else 0
        enviar("A,%d,%d,%d,%d\n" % (bpm, round(mov * 100), incl, round(pico * 100)))
        print("BPM:", bpm, "mov:", round(mov, 2), "incl:", incl, "pico:", round(pico, 2))
        suma_mov = 0.0
        n_mov = 0
        pico = 1.0

    sleep_ms(5)

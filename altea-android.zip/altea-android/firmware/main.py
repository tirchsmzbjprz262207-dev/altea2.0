# ALTEA v2 - firmware para ESP32-C3 mini (MicroPython)
# Sensores: MPU6050 (movimiento), MAX30102 (pulso), OLED SSD1306, motor vibrador
#
# Pulsera -> celular (BLE, una linea cada "intervalo"):  A,pulso,mov,incl,pico\n
#     pulso = latidos por minuto (0 si no hay lectura)
#     mov   = movimiento promedio en centesimas de g
#     incl  = inclinacion en grados
#     pico  = aceleracion maxima del periodo en centesimas de g (sirve para detectar caidas)
# Celular -> pulsera:  V<ms>  vibra el motor (V0 lo apaga)   |   I<ms>  cambia el intervalo (500 a 10000)

from machine import Pin, I2C
from time import sleep_ms, ticks_ms, ticks_diff
import framebuf
import bluetooth
import math

PIN_SCL = 9
PIN_SDA = 8
PIN_MOTOR = 4
NOMBRE_BLE = "ALTEA"
MPU_ADDR = 0x68
MAX_ADDR = 0x57
OLED_ADDR = 0x3C

i2c = I2C(0, scl=Pin(PIN_SCL), sda=Pin(PIN_SDA), freq=100000)
motor = Pin(PIN_MOTOR, Pin.OUT, value=0)


class OLED:
    def __init__(self, i2c, address=OLED_ADDR):
        self.i2c = i2c
        self.address = address
        self.buffer = bytearray(1024)
        self.fb = framebuf.FrameBuffer(self.buffer, 128, 64, framebuf.MONO_VLSB)
        for c in (0xAE, 0x20, 0x00, 0x40, 0xA1, 0xC8, 0x81, 0x7F, 0xA6,
                  0xA8, 0x3F, 0xD3, 0x00, 0xD5, 0x80, 0xD9, 0xF1, 0xDA,
                  0x12, 0xDB, 0x40, 0x8D, 0x14, 0xAF):
            self.command(c)

    def command(self, value):
        self.i2c.writeto(self.address, bytes([0x00, value]))

    def show(self):
        for c in (0x21, 0, 127, 0x22, 0, 7):
            self.command(c)
        self.i2c.writeto(self.address, b"\x40" + self.buffer)

    def clear(self):
        self.fb.fill(0)

    def text(self, mensaje, x, y):
        self.fb.text(mensaje, x, y, 1)


def leer_mpu():
    d = i2c.readfrom_mem(MPU_ADDR, 0x3B, 6)
    v = []
    for i in range(0, 6, 2):
        n = (d[i] << 8) | d[i + 1]
        if n > 32767:
            n -= 65536
        v.append(n / 16384)
    return v


class MAX30102:
    def __init__(self, i2c, addr=MAX_ADDR):
        self.i2c = i2c
        self.a = addr
        self.w(0x09, 0x40)
        sleep_ms(100)
        self.w(0x08, 0x5F)
        self.w(0x09, 0x03)
        self.w(0x0A, 0x2F)
        self.w(0x0C, 0x24)
        self.w(0x0D, 0x24)
        for r in (0x04, 0x05, 0x06):
            self.w(r, 0)

    def w(self, reg, val):
        self.i2c.writeto_mem(self.a, reg, bytes([val]))

    def r(self, reg):
        return self.i2c.readfrom_mem(self.a, reg, 1)[0]

    def muestras_ir(self):
        n = (self.r(0x04) - self.r(0x06)) & 0x1F
        out = []
        if n:
            d = self.i2c.readfrom_mem(self.a, 0x07, n * 6)
            for i in range(n):
                b = i * 6 + 3
                out.append(((d[b] << 16) | (d[b + 1] << 8) | d[b + 2]) & 0x3FFFF)
        return out


class Pulso:
    def __init__(self):
        self.reset()

    def reset(self):
        self.dc = 0
        self.lp = 0
        self.prev = 0
        self.amp = 0
        self.t = 0
        self.ultimo = None
        self.intervalos = []
        self.bpm = 0

    def agregar(self, ir):
        self.t += 10
        if ir < 30000:
            self.reset()
            return 0
        if self.dc == 0:
            self.dc = ir
        self.dc += (ir - self.dc) * 0.05
        x = self.dc - ir
        self.lp += (x - self.lp) * 0.3
        self.amp = max(abs(self.lp), self.amp * 0.995)
        umbral = max(self.amp * 0.35, 40)
        if self.prev < umbral <= self.lp:
            if self.ultimo is not None:
                dt = self.t - self.ultimo
                if 300 <= dt <= 2000:
                    self.intervalos.append(dt)
                    self.intervalos = self.intervalos[-5:]
                    self.bpm = int(60000 / (sum(self.intervalos) / len(self.intervalos)))
                if dt >= 300:
                    self.ultimo = self.t
            else:
                self.ultimo = self.t
        self.prev = self.lp
        if self.ultimo is not None and self.t - self.ultimo > 3000:
            self.bpm = 0
            self.intervalos = []
        return self.bpm


# ---------------- Bluetooth LE ----------------
UUID_SERVICIO = bluetooth.UUID("6E400001-B5A3-F393-E0A9-E50E24DCCA9E")
UUID_RX = bluetooth.UUID("6E400002-B5A3-F393-E0A9-E50E24DCCA9E")
UUID_TX = bluetooth.UUID("6E400003-B5A3-F393-E0A9-E50E24DCCA9E")

ble = bluetooth.BLE()
ble.active(True)
((h_tx, h_rx),) = ble.gatts_register_services((
    (UUID_SERVICIO, (
        (UUID_TX, bluetooth.FLAG_NOTIFY),
        (UUID_RX, bluetooth.FLAG_WRITE | bluetooth.FLAG_WRITE_NO_RESPONSE),
    )),
))

conexion = None
vibrar_hasta = 0
intervalo_ms = 2000


def publicitar():
    n = NOMBRE_BLE.encode()
    ble.gap_advertise(100000, adv_data=bytes([2, 0x01, 0x06, len(n) + 1, 0x09]) + n)


def irq(evento, datos):
    global conexion, vibrar_hasta, intervalo_ms
    if evento == 1:
        conexion = datos[0]
    elif evento == 2:
        conexion = None
        publicitar()
    elif evento == 3:
        try:
            msg = ble.gatts_read(h_rx).decode().strip()
            n = int(msg[1:])
        except (ValueError, UnicodeError):
            return
        if msg[0] == "V":
            vibrar_hasta = ticks_ms() + n if n > 0 else 0
        elif msg[0] == "I":
            intervalo_ms = min(10000, max(500, n))


ble.irq(irq)
publicitar()


def enviar(texto):
    if conexion is not None:
        try:
            ble.gatts_notify(conexion, h_tx, texto.encode())
        except OSError:
            pass


# ---------------- Arranque ----------------
print("ALTEA v2 - INICIANDO")
dispositivos = i2c.scan()
pantalla = None
if OLED_ADDR in dispositivos:
    try:
        pantalla = OLED(i2c)
    except OSError:
        pantalla = None

mpu_ok = MPU_ADDR in dispositivos
if mpu_ok:
    try:
        i2c.writeto_mem(MPU_ADDR, 0x6B, b"\x00")
        sleep_ms(100)
    except OSError:
        mpu_ok = False

sensor = None
if MAX_ADDR in dispositivos:
    try:
        sensor = MAX30102(i2c)
    except OSError:
        sensor = None

pulso = Pulso()
bpm = 0
ax = ay = 0.0
az = 1.0
suma_mov = 0.0
n_mov = 0
pico = 1.0
t_envio = ticks_ms()
t_mpu = ticks_ms()

# ---------------- Bucle principal ----------------
while True:
    ahora = ticks_ms()
    motor.value(1 if ticks_diff(vibrar_hasta, ahora) > 0 else 0)

    if sensor:
        try:
            for ir in sensor.muestras_ir():
                bpm = pulso.agregar(ir)
        except OSError:
            pass

    # acelerometro a ~50 Hz: promedio de movimiento y pico
    if mpu_ok and ticks_diff(ahora, t_mpu) >= 20:
        t_mpu = ahora
        try:
            ax, ay, az = leer_mpu()
            mag = math.sqrt(ax * ax + ay * ay + az * az)
            suma_mov += abs(mag - 1)
            n_mov += 1
            if mag > pico:
                pico = mag
        except OSError:
            pass

    if ticks_diff(ahora, t_envio) >= intervalo_ms:
        t_envio = ahora
        mov = (suma_mov / n_mov) if n_mov else 0
        mag = math.sqrt(ax * ax + ay * ay + az * az)
        incl = int(math.degrees(math.acos(max(-1, min(1, az / mag))))) if mag > 0.1 else 0
        enviar("A,%d,%d,%d,%d\n" % (bpm, round(mov * 100), incl, round(pico * 100)))
        print("BPM:", bpm, "mov:", round(mov, 2), "incl:", incl, "pico:", round(pico, 2))
        if pantalla:
            try:
                pantalla.clear()
                pantalla.text("ALTEA", 0, 0)
                pantalla.text("BLE: " + ("ok" if conexion is not None else "esperando"), 0, 14)
                pantalla.text("Pulso: " + (str(bpm) if bpm else "--"), 0, 27)
                pantalla.text("Mov: " + str(round(mov, 2)) + " g", 0, 39)
                pantalla.show()
            except OSError:
                pass
        suma_mov = 0.0
        n_mov = 0
        pico = 1.0

    sleep_ms(5)

# ALTEA v2 (app Android)

App para la pulsera ALTEA (ESP32-C3 + MAX30102 + MPU6050 + motor vibrador).
Muestra pulso, movimiento e inclinación, grafica el pulso en tiempo real, registra síntomas,
guarda un historial y avisa a un contacto de emergencia (SMS + WhatsApp, con ubicación).

Para instalarla sigue **GUIA-INSTALAR.md** (se compila sola en GitHub, no hace falta Android Studio).

## Estructura
- `app/src/main/java/com/altea/app/`: código Kotlin (Jetpack Compose).
  - `Altea.kt`: estado, reglas de alerta, historial. `Messenger.kt`: SMS y WhatsApp. `BleClient.kt` y `AlteaService.kt`: Bluetooth en segundo plano.
  - `Health.kt`: límites de pulso por edad. `Tr*.kt`: traducciones (es, en, fr, it, ja, zh, ru).
  - `MainActivity.kt`, `HomeScreens.kt`, `HistoryScreens.kt`, `CustomizeScreen.kt`, `SettingsScreen.kt`, `Onboarding.kt`, `Theme.kt`: pantallas.
- `firmware/main.py`: programa de la pulsera (MicroPython, se carga con Thonny).

## Protocolo Bluetooth (UART de Nordic)
- Pulsera → celular, cada "intervalo": `A,pulso,mov,incl,pico` (mov y pico en centésimas de g, incl en grados).
- Celular → pulsera: `V<ms>` vibra el motor (`V0` lo apaga), `I<ms>` cambia el intervalo (500 a 10000).
- UUID del servicio: `6e400001-b5a3-f393-e0a9-e50e24dcca9e`.

## Límites de pulso por defecto
Rango normal en reposo (Cleveland Clinic): bebés 100–180, 1–3 años 98–140, 3–5 años 80–120, 5–12 años 75–118,
adolescentes y adultos 60–100. Alerta alta = máximo normal + 20 (+10 con antecedentes cardiacos), alerta baja = mínimo normal − 10,
ambas tras 20 s seguidos. Subida brusca en reposo: +30 lpm en adultos, +40 en menores de 20 años (criterio de POTS).
Son valores de apoyo, no un diagnóstico, y se pueden cambiar en Ajustes.
